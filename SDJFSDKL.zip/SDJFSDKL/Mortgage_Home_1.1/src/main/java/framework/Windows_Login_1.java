/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2015. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package framework;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

/**
 * <p>
 * <b> TODO : This Class is used to handle windows Authentication </b>
 * </p>
 */
public class Windows_Login_1 {
    String username;
    String Passwrd;

    boolean valueSet = false;

    public synchronized void login(final String uname, final String pswd) throws InterruptedException, AWTException {
        // if (!this.valueSet) {


        this.username = uname;
        this.Passwrd = pswd;
        Thread.sleep(5000);
        // create robot for keyboard operations
        Robot rb = new Robot();


        // System.out.println("Username1 :" + uname);
        StringSelection username = new StringSelection(uname);
        // System.out.println("Username :" + username);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(username, null);

        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_V);
        rb.keyRelease(KeyEvent.VK_V);
        rb.keyRelease(KeyEvent.VK_CONTROL);


        rb.keyPress(KeyEvent.VK_TAB);
        rb.keyRelease(KeyEvent.VK_TAB);
        Thread.sleep(5000);
        StringSelection pwd = new StringSelection(pswd);
        // System.out.println("pwd :" + pwd);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pwd, null);
        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_V);
        rb.keyRelease(KeyEvent.VK_V);
        rb.keyRelease(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_ENTER);
        rb.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(5000);
    }

}
