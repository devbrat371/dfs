/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2015. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package framework;

/**
 * <p>
 * <b> TODO : This Class is used to handle windows Authentication. </b>
 * </p>
 */
public class Windows_Login_2 extends Thread {
    private Windows_Login_1 wl;

    public Windows_Login_2(final Windows_Login_1 wl, final String name) {
        super(name); // Save thread's name
        this.wl = wl;
    }


    public void run() {
        String UserID = null;
        String Password = null;
        try {
            if (Library.Environment.equalsIgnoreCase("SIT")) {
                UserID = Framework.getConfigData("SIT_Customer_UserID");
                Password = Framework.getConfigData("SIT_Customer_Password");
            }
            if (Library.Environment.equalsIgnoreCase("DIT")) {
                UserID = Framework.getConfigData("DIT_Customer_UserID");
                Password = Framework.getConfigData("DIT_Customer_Password");
            }
            if (Library.Environment.equalsIgnoreCase("UAT")) {
                UserID = Framework.getConfigData("UAT_Customer_UserID");
                Password = Framework.getConfigData("UAT_Customer_Password");
            }
            if (getName().equals("FirstLogin")) {

                this.wl.login(UserID, Password);
            } else {
                this.wl.login(UserID, Password);
            }

        } catch (Exception ex) {
            System.out.println("Error in Login Thread: " + ex.getMessage());
        }
    }

}
