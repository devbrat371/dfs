/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package framework;

import java.io.File;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import PageObjectModel.Agent_Login_Page;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Library extends Framework {
    public static String Environment;
    static Agent_Login_Page agent_login_page;

    // public static boolean HC_Flag = false;

    public static WebDriver startSelenium(WebDriver driver, final String browser, final String channel, final String Env)
        throws Exception {

        Framework.dir = System.getProperty("user.dir");
        // String browser = getConfigData("Browser");
        Library.Environment = Env;
        if (browser.equalsIgnoreCase("Firefox")) {
            FirefoxProfile profile = new FirefoxProfile();
            try {
                final String firebugPath = "C://SWDTOOLS//Selenium//firepath//firebug-1.12.8.xpi";
                final String firebugPath1 = "C://SWDTOOLS//Selenium//firepath//firepath-0.9.7.1-fx.xpi";


                profile.addExtension(new File(firebugPath));
                profile.addExtension(new File(firebugPath1));
            } catch (Exception E) {

            }
            driver = new FirefoxDriver(profile);

            atu.testng.reports.ATUReports.setWebDriver(driver);

            if (channel.equalsIgnoreCase("agent")) {
                if (Library.Environment.equalsIgnoreCase("341")) {
                    driver.get(getConfigData("SIT_Agent_URL341"));
                    Library.agent_login_page = new Agent_Login_Page(driver);
                    Library.agent_login_page.Agent_Login(driver, getConfigData("SIT_Agent_UserID341"),
                        getConfigData("SIT_Agent_Password341"));
                    driver.get(getConfigData("SIT_Agent_URL341_2"));
                } else if (Library.Environment.equalsIgnoreCase("463")) {
                    driver.get(getConfigData("SIT_Agent_URL463"));
                    // Library.url = getConfigData("SIT_Agent_URL463");
                    Library.agent_login_page.Agent_Login(driver, getConfigData("SIT_Agent_UserID463"),
                        getConfigData("SIT_Agent_Password463"));
                    driver.get(getConfigData("SIT_Agent_URL463_2"));
                } else if (Library.Environment.equalsIgnoreCase("342")) {
                    driver.get(getConfigData("SIT_Agent_URL342"));
                    // Library.url = getConfigData("SIT_Agent_URL342");
                    Library.agent_login_page.Agent_Login(driver, getConfigData("SIT_Agent_UserID342"),
                        getConfigData("SIT_Agent_Password342"));
                    driver.get(getConfigData("SIT_Agent_URL342_2"));
                }
            } else if (channel.equalsIgnoreCase("customer")) {
                Windows_Login_1 wl = new Windows_Login_1();
                Windows_Login_2 tt1 = new Windows_Login_2(wl, "FirstLogin");
                if (Library.Environment.equalsIgnoreCase("SIT")) {
                    tt1.start();
                    driver.get(getConfigData("SIT_Customer_URL"));
                    // Library.url = getConfigData("SIT_Customer_URL");
                } else if (Library.Environment.equalsIgnoreCase("DIT")) {
                    tt1.start();
                    driver.get(getConfigData("DIT_Customer_URL"));
                    // Library.url = getConfigData("DIT_Customer_URL");
                } else if (Library.Environment.equalsIgnoreCase("UAT")) {
                    tt1.start();
                    driver.get(getConfigData("UAT_Customer_URL"));
                    // Library.url = getConfigData("UAT_Customer_URL");
                }
            }
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(5, TimeUnit.SECONDS).ignoring(
                NoSuchElementException.class);
        }

        if (browser.equalsIgnoreCase("Chrome")) {
            System.setProperty("webdriver.chrome.driver",
                "C:\\SWDTOOLS\\Selenium\\Selenium-ChromeDriver v32_2.3 (to support chrome v28-31)\\chromedriver.exe");
            driver = new ChromeDriver();

            if (channel.equalsIgnoreCase("Agent_Channel")) {
                driver.get(getConfigData("Agent_URL"));
            } else if (channel.equalsIgnoreCase("Customer_Channel")) {
                Windows_Login_1 wl = new Windows_Login_1();
                Windows_Login_2 tt1 = new Windows_Login_2(wl, "FirstLogin");
                tt1.start();
                driver.get(getConfigData("Customer_URL"));
            }
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        }

        if (browser.equalsIgnoreCase("ie")) {
            System
                .setProperty("webdriver.ie.driver",
                    "C:\\SWDTOOLS\\Selenium\\Selenium-Internet Explorer Driver Server v2.35.3 (for 32 bit Windows IE)\\IEDriverServer.exe");
            driver = new InternetExplorerDriver();
            if (channel.equalsIgnoreCase("Agent_Channel")) {
                driver.get(getConfigData("Agent_URL"));
            } else if (channel.equalsIgnoreCase("Customer_Channel")) {
                Windows_Login_1 wl = new Windows_Login_1();
                Windows_Login_2 tt1 = new Windows_Login_2(wl, "FirstLogin");
                tt1.start();
                driver.get(getConfigData("Customer_URL"));
            }

            try {
                driver.get("javascript:document.getElementById('overridelink').click();");
                Thread.sleep(2000);
            } catch (Exception e) {
                System.out.println("No Override link present");
            }
            boolean flag = true;
            while (flag) {
                try {
                    Alert alert = driver.switchTo().alert();
                    alert.accept();
                    // System.out.println("Alert Present");

                } catch (Exception ex) {
                    // System.out.println("No Alret Present");
                    flag = false;
                }
            }
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        }
        return driver;
    }

    public static void Select_Loan(final WebDriver driver) throws Exception {
        // String fee_free = gettestdata("Fee_Free");

        int no_of_loan = Integer.parseInt(gettestdata("Number_of_Loans"));

        int a = 100000 / no_of_loan;
        String amount_per_loan = Integer.toString(a);
        int i = 1;
        Select select_mortgage_type;
        while (i <= no_of_loan) {
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseHOL"))).click();
                driver.findElement(By.xpath(getobjectdata("Quotes", "filter_results"))).click();
                select_mortgage_type = new Select(driver.findElement(By.xpath(getobjectdata("Quotes", "HOL_type"))));

                String loan_type = "Loan_Type" + i;

                select_mortgage_type.selectByVisibleText(gettestdata(loan_type));

                driver.findElement(By.xpath(getobjectdata("Quotes", "update_HOL_result"))).click();
                driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseHOL"))).click();

                driver.findElement(By.xpath(getobjectdata("Quotes", "Select_random_Rates"))).click();
                if (i < no_of_loan) {

                    driver.findElement(By.xpath(getobjectdata("Quotes", "Selected_HOL"))).click();

                    List<WebElement> Edit_Rate = driver.findElements(By.xpath(getobjectdata("Quotes", "Edit_HOL_Rate")));
                    Edit_Rate.get(i - 1).click();
                    driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_HOL_Amount_Button"))).click();
                    driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_HOL_Amount_Field"))).clear();
                    driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_HOL_Amount_Field"))).sendKeys(amount_per_loan);
                    driver.findElement(By.xpath(getobjectdata("Quotes", "save_HOL_Amount_change"))).click();

                    driver.findElement(By.xpath(getobjectdata("Quotes", "choose_another_HOL"))).click();

                }
                i++;
            }

            else {

                driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseMortgage"))).click();

                driver.findElement(By.xpath(getobjectdata("Quotes", "filter_results"))).click();
                select_mortgage_type = new Select(driver.findElement(By.xpath(getobjectdata("Quotes", "mortgage_type"))));

                String loan_type = "Loan_Type" + i;

                select_mortgage_type.selectByVisibleText(gettestdata(loan_type));

                driver.findElement(By.xpath(getobjectdata("Quotes", "update_result"))).click();
                driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseMortgage"))).click();

                driver.findElement(By.xpath(getobjectdata("Quotes", "Select_random_Rates"))).click();
                if (i < no_of_loan) {
                    driver.findElement(By.xpath(getobjectdata("Quotes", "Selected_Rates"))).click();

                    List<WebElement> Edit_Rate = driver.findElements(By.xpath(getobjectdata("Quotes", "Edit_Rate")));
                    Edit_Rate.get(i - 1).click();
                    driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Amount_Button"))).click();
                    driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Amount_Field"))).clear();
                    driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Amount_Field"))).sendKeys(amount_per_loan);
                    driver.findElement(By.xpath(getobjectdata("Quotes", "save_Amount_change"))).click();

                    driver.findElement(By.xpath(getobjectdata("Quotes", "choose_another_mortgage"))).click();

                }
                i++;

            }
        }
    }
}
