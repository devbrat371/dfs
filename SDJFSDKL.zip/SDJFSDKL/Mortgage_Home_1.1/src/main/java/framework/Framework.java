/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2015. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package framework;

import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import DataProvider.TestDataProvider;
import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;
import atu.testng.reports.logging.LogAs;
import atu.testng.selenium.reports.CaptureScreen;
import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;


/**
 * <p>
 * <b> TODO : Framework for Switcher Flow </b>
 * </p>
 */
@Listeners({ATUReportsListener.class, ConfigurationListener.class, MethodListener.class})
public class Framework {
    {
        System.setProperty("atu.reporter.config", "src/main/resources/atu.properties");
    }
    protected static ATUReports ATUReports;
    public static String dir;
    protected static int rowCols;
    protected static int Appid_row_no;
    protected static int Userid_row_no;
    protected static int result_row_no;
    public static final org.apache.log4j.Logger Log = org.apache.log4j.Logger.getLogger(Framework.class);


    protected static String getConfigData(final String parameter) throws FileNotFoundException, IOException {

        File f = new File(Framework.dir + "\\src\\main\\java\\TestData\\config.properties");
        Properties prop = new Properties();
        prop.load(new FileInputStream(f));
        String Property_Value = prop.getProperty(parameter);
        return Property_Value;
    }

    public static String getobjectdata(final String pageElementTagname, final String ElementName) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new File(Framework.dir + "\\src\\data\\objectdata.xml"));
        Element root = document.getDocumentElement();
        NodeList departments = root.getElementsByTagName("page");

        for (int i = 0; i < departments.getLength(); i++) {
            Element department = (Element) departments.item(i);
            String department1 = department.getAttribute("name");
            if (department1.equals(pageElementTagname)) {
                NodeList groups = department.getElementsByTagName("uiobject");
                for (int j = 0; j < groups.getLength(); j++) {
                    Element group = (Element) groups.item(j);
                    String department2 = group.getAttribute("name");

                    if (department2.equals(ElementName)) {
                        root.normalize();
                        String body = group.getFirstChild().getNodeValue();
                        return body;
                    }
                }
            }

        }
        return null;
    }


    public static void closeSelenium(final WebDriver driver) {

        driver.quit();
    }

    public static void takeScreenshot(final WebDriver driver, final String testname) throws IOException, InterruptedException {
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        Thread.sleep(2000);
        String strDirectoy = Framework.dir + "\\Screenshots";
        File destFile = new File(strDirectoy + "\\" + testname + ".png");

        TakesScreenshot ts = ((TakesScreenshot) driver);
        File src_File = ts.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(src_File, destFile);

    }

    public static void Display_Popup(final String Title, final String Message) {
        Toolkit.getDefaultToolkit().beep();
        JOptionPane optionPane = new JOptionPane(Message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(Title);
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
    }

    public static String Display_InputPopup() {

        String info = JOptionPane.showInputDialog("Please enter the text Displayed in the Captcha: ");
        return info;

    }

    public static String Read_Environment() {

        String env = JOptionPane.showInputDialog("Please enter the Environment(SIT/DIT/UAT)");
        if (env.equalsIgnoreCase("SIT") || env.equalsIgnoreCase("DIT") || env.equalsIgnoreCase("UAT")) {
            return env;
        } else {
            return Read_Environment();
        }


    }

    public static int rowCounttestCase;
    static Map<String, Object> rowMap = null;

    public static void readExcel() throws IOException {
        FileInputStream file = new FileInputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet spreadsheet = workbook.getSheet("Sheet1");

        Framework.rowCounttestCase = spreadsheet.getLastRowNum() - spreadsheet.getFirstRowNum();

        // System.out.println("lastrowcount=" + spreadsheet.getLastRowNum());
        // System.out.println("firstrowcount=" + spreadsheet.getFirstRowNum());
        System.out.println("rowcount=" + Framework.rowCounttestCase);

        Framework.rowCols = spreadsheet.getRow(0).getPhysicalNumberOfCells() - 1;
        System.out.println("column count:" + Framework.rowCols);
        file.close();
    }

    public static void fetchrowdata() throws Exception {

        FileInputStream file = new FileInputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet spreadsheet = workbook.getSheet("Sheet1");
        Row rowtestCase = spreadsheet.getRow(TestDataProvider.rowCount);
        // System.out.println("######" + rowtestCase.getRowNum());

        XSSFRow row = null;
        Framework.rowMap = null;

        row = spreadsheet.getRow(0);
        Framework.rowMap = new HashMap<String, Object>(Framework.rowCols);
        // if (rowtestCase.getCell(0).toString().equalsIgnoreCase("Y")) {
        for (int c = 0; c <= Framework.rowCols; c++) {
            if (row.getCell(c).getStringCellValue().equalsIgnoreCase("App_ID")) {
                Framework.Appid_row_no = c;
            }
            if (row.getCell(c).getStringCellValue().equalsIgnoreCase("User_ID")) {
                Framework.Userid_row_no = c;
            }
            if (row.getCell(c).getStringCellValue().equalsIgnoreCase("Result")) {
                Framework.result_row_no = c;
            }
        }
        for (int c = 0; c <= Framework.rowCols - 3; c++) {
            Framework.rowMap.put(row.getCell(c).getStringCellValue(), rowtestCase.getCell(c).getStringCellValue());
            /*
             * if
             * (rowtestCase.getCell(0).getStringCellValue().equalsIgnoreCase(
             * "Y")) { System.out.println("Key: " +
             * row.getCell(c).getStringCellValue() + ",value:" +
             * rowtestCase.getCell(c).getStringCellValue());
             * 
             * }
             */
        }

        file.close();
    }

    public static int getrowexecutioncount() throws Exception {
        int rowcount = 0;
        for (TestDataProvider.rowCount = 1; TestDataProvider.rowCount <= Framework.rowCounttestCase; TestDataProvider.rowCount++) {

            fetchrowdata();
            if (gettestdata("RunStatus").toString().equalsIgnoreCase("Y")) {
                rowcount++;
            }
        }
        return rowcount;
    }

    public static String gettestdata(final String data) throws Exception {

        String value = Framework.rowMap.get(data).toString();
        return value;

    }

    public static void update_AppID(final int row, final String result) throws IOException {
        FileInputStream file = new FileInputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));

        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet spreadsheet = workbook.getSheet("Sheet1");
        Cell cell = null;
        if (cell == null) {
            cell = spreadsheet.getRow(row).createCell(Framework.Appid_row_no);
        }

        cell.setCellValue(result);

        file.close();
        FileOutputStream output_file = new FileOutputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));

        // write changes
        workbook.write(output_file);

        // close the stream
        output_file.close();
    }

    public static void update_UserID(final int row, final String result) throws IOException {
        FileInputStream file = new FileInputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));

        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet spreadsheet = workbook.getSheet("Sheet1");
        Cell cell = null;
        if (cell == null) {
            cell = spreadsheet.getRow(row).createCell(Framework.Userid_row_no);
        }

        cell.setCellValue(result);

        file.close();
        FileOutputStream output_file = new FileOutputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));

        // write changes
        workbook.write(output_file);

        // close the stream
        output_file.close();
    }

    public static void update_Result(final int row, final String result) throws IOException {
        FileInputStream file = new FileInputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));

        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet spreadsheet = workbook.getSheet("Sheet1");
        Cell cell = null;
        if (cell == null) {
            cell = spreadsheet.getRow(row).createCell(Framework.result_row_no);
        }

        cell.setCellValue(result);
        if (result.equalsIgnoreCase("PASS")) {
            CellStyle style = workbook.createCellStyle();
            style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
            style.setFillPattern(CellStyle.ALIGN_FILL);
            style.setBorderBottom(CellStyle.BORDER_THIN);
            style.setBorderRight(CellStyle.BORDER_THIN);
            cell.setCellStyle(style);
        } else if (result.equalsIgnoreCase("FAIL")) {
            CellStyle style = workbook.createCellStyle();
            style.setFillBackgroundColor(IndexedColors.RED.getIndex());
            style.setFillPattern(CellStyle.ALIGN_FILL);
            style.setBorderBottom(CellStyle.BORDER_THIN);
            style.setBorderRight(CellStyle.BORDER_THIN);
            cell.setCellStyle(style);
        } else if (result.equalsIgnoreCase("NO RUN")) {
            CellStyle style = workbook.createCellStyle();
            style.setFillBackgroundColor(IndexedColors.YELLOW.getIndex());
            style.setFillPattern(CellStyle.ALIGN_FILL);
            style.setBorderBottom(CellStyle.BORDER_THIN);
            style.setBorderRight(CellStyle.BORDER_THIN);
            cell.setCellStyle(style);
        }
        file.close();
        FileOutputStream output_file = new FileOutputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));

        // write changes
        workbook.write(output_file);

        // close the stream
        output_file.close();
    }

    static Random r = new Random();

    static char[] choices = ("ABCDEFGHIJKLMNOPQRSTUVWXYZ").toCharArray();

    public static String get_random_char(final int len) {
        StringBuilder random_char = new StringBuilder(len);
        for (int i = 0; i < len; ++i) {
            random_char.append(Framework.choices[Framework.r.nextInt(Framework.choices.length)]);
        }
        return random_char.toString();
    }

    public static void log_report(final String statuslog, final String statumsg, final String capturescreenshot) {

        String callerClassName = new Exception().getStackTrace()[1].getClassName();
        // String calleeClassName = new
        // Exception().getStackTrace()[0].getClassName();
        String clsname = callerClassName.substring(callerClassName.indexOf(".") + 1);


        final org.apache.log4j.Logger Log = org.apache.log4j.Logger.getLogger(clsname);
        if (statuslog.equalsIgnoreCase("Pass") && capturescreenshot.equalsIgnoreCase("Yes")) {
            atu.testng.reports.ATUReports.add("Pass Step", LogAs.PASSED, new CaptureScreen(ScreenshotOf.BROWSER_PAGE));

        } else if (statuslog.equalsIgnoreCase("Fail") && capturescreenshot.equalsIgnoreCase("Yes")) {
            atu.testng.reports.ATUReports.add("Fail Step", LogAs.FAILED, new CaptureScreen(ScreenshotOf.BROWSER_PAGE));

        } else if (statuslog.equalsIgnoreCase("Info") && capturescreenshot.equalsIgnoreCase("Yes")) {
            atu.testng.reports.ATUReports.add("Info Step", LogAs.INFO, new CaptureScreen(ScreenshotOf.BROWSER_PAGE));
        }
        Reporter.log(statumsg);
        Log.info(statumsg);
        // Log.info("callee " + clsname);
        // Log.info("caller " + callerClassName);
    }
}
