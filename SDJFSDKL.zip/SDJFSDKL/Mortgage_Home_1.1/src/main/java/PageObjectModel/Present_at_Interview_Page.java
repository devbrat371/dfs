/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Present_at_Interview_Page {
    private WebDriver driver;
    // Search Customer
    @FindBy(xpath = "//input[contains(@id,'presentradiobutton-option_1')]")
    WebElement presentradiobutton_Yes;
    @FindBy(xpath = "//input[contains(@id,'save-button-enable')]")
    WebElement Save_Button;
    @FindBy(xpath = "//input[contains(@id,'present_at_interview_form:agree-radioButton_1')]")
    WebElement Joint_applicant_access;

    public Present_at_Interview_Page(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void select_presentradiobutton_Yes(final WebDriver driver) {
        this.presentradiobutton_Yes.click();
    }

    public void click_Save_Button(final WebDriver driver) {
        this.Save_Button.click();
    }

    public void click_Joint_applicant_access(final WebDriver driver) {
        this.Joint_applicant_access.click();
    }

    public void fill_present_at_interview(final WebDriver driver, final String joint_applicant) {
        select_presentradiobutton_Yes(this.driver);
        if (joint_applicant.equalsIgnoreCase("Yes")) {
            click_Joint_applicant_access(this.driver);
        }
        click_Save_Button(this.driver);
    }
}
