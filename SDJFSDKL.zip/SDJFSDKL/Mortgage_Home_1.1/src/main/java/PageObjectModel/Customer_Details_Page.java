/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import framework.Framework;

public class Customer_Details_Page extends Framework {
    private WebDriver driver;
    // Search Customer
    @FindBy(xpath = "//select[contains(@id,'titledropdown-option')]")
    WebElement title;
    @FindBy(xpath = "//input[contains(@id,'firstnamedetails-field')]")
    WebElement first_name;
    @FindBy(xpath = "//input[contains(@id,'lastnamedetails-field')]")
    WebElement last_name;
    @FindBy(xpath = "//input[contains(@id,'date-field')]")
    WebElement date;
    @FindBy(xpath = "//input[contains(@id,'month-fieldd')]")
    WebElement month;
    @FindBy(xpath = "//input[contains(@id,'year-field')]")
    WebElement year;
    @FindBy(xpath = "//input[contains(@id,'genderradiobutton-option_1')]")
    WebElement gender_male;
    @FindBy(xpath = "//input[contains(@id,'genderradiobutton-option_2')]")
    WebElement gender_female;
    @FindBy(xpath = "//input[contains(@id,'search-applicant-nav-button-enable')]")
    WebElement application_search;
    @FindBy(xpath = "//input[contains(@id,'non-of-the-above-radiobutton-two-option-2')]")
    WebElement non_of_the_above_rad_button;
    @FindBy(xpath = "//input[contains(@id,'confirmbutton-nav-enable2')]")
    WebElement confirm;
    // Add Customer
    @FindBy(xpath = "//input[contains(@id,'homeTelephoneIntl-field')]")
    WebElement home_telephone_intl;
    @FindBy(xpath = "//input[contains(@id,'homeTelephoneStd-field')]")
    WebElement home_telephone_std;
    @FindBy(xpath = "//input[contains(@id,'homeTelephoneNumber-field')]")
    WebElement home_telephone_number;
    @FindBy(xpath = "//input[contains(@id,'mobileNumberIntl-field')]")
    WebElement mobile_telephone_intl;
    @FindBy(xpath = "//input[contains(@id,'mobileNumberStd-field')]")
    WebElement mobile_telephone_std;
    @FindBy(xpath = "//input[contains(@id,'mobileNumberNumber-field')]")
    WebElement mobile_telephone_number;
    @FindBy(xpath = "//input[contains(@id,'emailaddressdetails-field')]")
    WebElement email;
    @FindBy(xpath = "//input[contains(@id,':gad_address:ukMainland-postcode')]")
    WebElement postcode;
    @FindBy(xpath = "//input[contains(@id,'gad_address:fe-current-findaddress-nav')]")
    WebElement find_address;
    @FindBy(xpath = "//select[contains(@id,'gad_address:addresslistbox-option')]")
    WebElement address_list_box;
    @FindBy(xpath = "//select[contains(@id,'applicat:yearsAtCurrentAddress')]")
    WebElement years_at_currentaddress;
    @FindBy(xpath = "//select[contains(@id,'applicat:months')]")
    WebElement months_at_currentaddress;
    @FindBy(xpath = "//input[contains(@id,'savebutton-nav')]")
    WebElement save;

    public Customer_Details_Page(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void settitle(final WebDriver driver, final String title) {
        Select select = new Select(this.title);
        select.selectByVisibleText(title);
    }

    public void setfirstname(final WebDriver driver, final String first_name) {
        this.first_name.sendKeys(first_name);
    }

    public void setlastname(final WebDriver driver, final String last_name) {
        this.last_name.sendKeys(last_name);
    }

    public void setdate(final WebDriver driver, final String date) {
        this.date.sendKeys(date);
    }

    public void setmonth(final WebDriver driver, final String month) {
        this.month.sendKeys(month);
    }

    public void setyear(final WebDriver driver, final String year) {
        this.year.sendKeys(year);
    }

    public void setgender(final WebDriver driver, final String gender) {
        if (gender.equalsIgnoreCase("M")) {
            this.gender_male.click();
        } else {
            this.gender_female.click();
        }
    }

    public void clickappsearch(final WebDriver driver) {
        this.application_search.click();
    }

    public void set_home_tel(final WebDriver driver, final String home_telephone_intl, final String home_telephone_std,
        final String home_telephone_number) {
        this.home_telephone_intl.sendKeys(home_telephone_intl);
        this.home_telephone_std.sendKeys(home_telephone_std);
        this.home_telephone_number.sendKeys(home_telephone_number);
    }

    public void set_mobile_tel(final WebDriver driver, final String mobile_telephone_intl, final String mobile_telephone_std,
        final String mobile_telephone_number) {
        this.mobile_telephone_intl.sendKeys(mobile_telephone_intl);
        this.mobile_telephone_std.sendKeys(mobile_telephone_std);
        this.mobile_telephone_number.sendKeys(mobile_telephone_number);
    }

    public void setemail(final WebDriver driver, final String email) {
        this.email.sendKeys(email);
    }

    public void setpostcode(final WebDriver driver, final String postcode) {
        this.postcode.sendKeys(postcode);
    }

    public void click_find_address(final WebDriver driver) {
        this.find_address.click();
    }

    public void set_address_list_box(final WebDriver driver, final String address_list_box) {
        Select select = new Select(this.address_list_box);
        select.selectByVisibleText(address_list_box);
    }

    public void settime_at_currentaddress(final WebDriver driver, final String years_at_currentaddress,
        final String months_at_currentaddress) {
        Select select = new Select(this.years_at_currentaddress);
        select.selectByVisibleText(years_at_currentaddress);
        Select select1 = new Select(this.months_at_currentaddress);
        select1.selectByVisibleText(months_at_currentaddress);

    }

    public void click_save(final WebDriver driver) {
        this.save.click();
    }

    public void search_newcustomer(final WebDriver driver) {
        settitle(this.driver, "Mr");
        setfirstname(this.driver, "MYR" + Framework.get_random_char(5));
        setlastname(this.driver, "Test" + Framework.get_random_char(5));
        setdate(this.driver, "21");
        setmonth(this.driver, "03");
        setyear(this.driver, "1988");
        setgender(this.driver, "M");
        clickappsearch(this.driver);
    }

    public void add_customer(final WebDriver driver) {
        set_home_tel(driver, "+011", "1111", "1111");
        set_mobile_tel(driver, "+0111", "1111111", "11111");
        setemail(driver, "MYR" + get_random_char(5) + "@HSBC.com");
        setpostcode(driver, "s2 3gg");
        click_find_address(driver);
        set_address_list_box(driver, "72, Heeley Bank Road, Sheffield, S2 3GG");
        settime_at_currentaddress(driver, "9", "11");
        click_save(driver);
    }

}
