/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Customer_Search_Result_Page {
    private WebDriver driver;
    @FindBy(xpath = "//input[contains(@id,'non-of-the-above-radiobutton-two-option-2')]")
    WebElement non_of_the_above_rad_button;
    @FindBy(xpath = "//input[contains(@id,'confirmbutton-nav-enable2')]")
    WebElement confirm;

    public Customer_Search_Result_Page(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void click_non_of_the_above_rad_button(final WebDriver driver) {
        this.non_of_the_above_rad_button.click();
    }

    public void clickconfirm(final WebDriver driver) {
        this.confirm.click();
    }

    public void select_new_customer(final WebDriver driver) {
        click_non_of_the_above_rad_button(this.driver);
        clickconfirm(this.driver);
    }
}
