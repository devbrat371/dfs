/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Agent_Login_Page {

    private WebDriver driver;

    // Declaration of Objects.
    @FindBy(xpath = "//input[@id='userID']")
    WebElement user_id;
    @FindBy(xpath = "//input[@id='password']")
    WebElement password;
    @FindBy(xpath = "//input[@value='Log in']")
    WebElement login_button;

    public Agent_Login_Page(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void setUserid(final WebDriver driver, final String userid) {
        this.user_id.sendKeys(userid);
    }

    public void setpassword(final WebDriver driver, final String pwd) {
        this.password.sendKeys(pwd);
    }

    public void clicklogin(final WebDriver driver) {
        this.login_button.click();
    }

    public void Agent_Login(final WebDriver driver, final String username, final String password) {
        setUserid(driver, username);
        setpassword(driver, password);
        clicklogin(driver);
    }
}
