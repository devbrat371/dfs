/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Agent_Gateway_Page {
    private WebDriver driver;
    // Search Customer
    @FindBy(xpath = "//input[contains(@id,'dipbutton-nav')]")
    WebElement DIP_Button;
    @FindBy(xpath = "//input[contains(@id,'addapplicantbutton')]")
    WebElement Add_Applicant;

    public Agent_Gateway_Page(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void click_DIP_Button(final WebDriver driver) {
        this.DIP_Button.click();
    }

    public void click_Add_Applicant(final WebDriver driver) {
        this.Add_Applicant.click();
    }

}
