/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package PageObjectModel;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Before_Your_Start_Page {
    private WebDriver driver;
    // Search Customer
    @FindBy(xpath = "//input[contains(@id,'triage-responsefield_1')]")
    WebElement Triage_Response_1;
    @FindBy(xpath = "//div/img")
    WebElement captcha;
    @FindBy(xpath = "//input[contains(@id,'captchaInput')]")
    WebElement captcha_text;
    @FindBy(xpath = "//input[contains(@name,'continueApplication')]")
    List<WebElement> Continue_App;

    public Before_Your_Start_Page(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void click_Triage_Response_1(final WebDriver driver) {
        this.Triage_Response_1.click();
    }

    public void click_continue(final WebDriver driver) {
        for (int i = 0; i < this.Continue_App.size(); i++) {

            if (this.Continue_App.get(i).isDisplayed() && this.Continue_App.get(i).isEnabled()) {
                this.Continue_App.get(i).click();
                i = this.Continue_App.size();
            }
        }
    }

    public void fill_triage_response(final WebDriver driver) {
        click_Triage_Response_1(this.driver);
        click_continue(this.driver);
    }
}
