/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class What_would_you_like_to_do_Page {
    private WebDriver driver;
    @FindBy(xpath = "//input[contains(@id,'propertytype-option_1')]")
    WebElement property_option1;
    @FindBy(xpath = "//input[contains(@id,'propertytype-option_2')]")
    WebElement property_option2;
    @FindBy(xpath = "//input[contains(@id,'propertytype-option_3')]")
    WebElement property_option3;
    @FindBy(xpath = "//select[contains(@id,'buyertypeMainHome-option')]")
    WebElement buyertype_mainhome;
    @FindBy(xpath = "//select[contains(@id,'buyertypeSecondHome-option')]")
    WebElement buyertype_secondhome;
    @FindBy(xpath = "//select[contains(@id,'buyertypeBTL-option')]")
    WebElement buyertype_BTL_mainhome;
    @FindBy(xpath = "//input[contains(@id,'debtConsolidationMainHome-option_2')]")
    WebElement debtConsolidationMainHome_Yes;
    @FindBy(xpath = "//input[contains(@id,'debtConsolidationMainHome-option_1')]")
    WebElement debtConsolidationMainHome_No;
    @FindBy(xpath = "//input[contains(@id,'debtConsolidationSecondHome-option_2')]")
    WebElement debtConsolidationSecondHome_Yes;
    @FindBy(xpath = "//input[contains(@id,'debtConsolidationSecondHome-option_1')]")
    WebElement debtConsolidationSecondHome_No;
    @FindBy(xpath = "//input[contains(@id,'waysToCoverMortgage_F_S-option_1')]")
    WebElement way_to_cover_mortgage;
    @FindBy(xpath = "//input[contains(@id,'waysToCoverMortgage_T-option_1')]")
    WebElement way_to_cover_mortgage_transfer_borrowmore;
    @FindBy(xpath = "//input[contains(@id,'intendToOccupyProperty_FS-option_1')]")
    WebElement intend_to_occupy_property;
    @FindBy(xpath = "//input[contains(@id,'intendToOccupyProperty_T-option_1')]")
    WebElement intend_to_occupy_property_transfer_borrowmore;
    @FindBy(xpath = "//input[contains(@id,'RightToBuyScheme-option_1')]")
    WebElement Right_to_buy_no;
    @FindBy(xpath = "//input[contains(@id,'RightToBuyScheme-option_2')]")
    WebElement Right_to_buy_yes;
    @FindBy(xpath = "//input[contains(@id,'occupiedInLastFiveYrs_T-option_1')]")
    WebElement own_other_BTL_No;
    @FindBy(xpath = "//input[contains(@id,'inheritedInLastFiveYrs_T-option_1')]")
    WebElement Let_out_for_business_No;
    @FindBy(xpath = "//input[contains(@id,'inheritedInLastFiveYrs_T-option_2')]")
    WebElement Let_out_for_business_Yes;
    @FindBy(xpath = "//input[contains(@id,'submitContinue')]")
    WebElement submit;
    @FindBy(xpath = "//input[contains(@id,'advice')]")
    WebElement advice_flow_button;
    @FindBy(xpath = "//input[contains(@id,'keyFactButton_eo')]")
    WebElement EO_flow_button;
    @FindBy(xpath = "//input[contains(@id,'nonAdviceOnly')]")
    WebElement NonAdvice_flow_button;
    @FindBy(xpath = "//input[contains(@id,'continueWithAdvice')]")
    WebElement continuewithadvice_button;
    @FindBy(xpath = "//input[contains(@id,'continueExecuteOnlyNav')]")
    WebElement continuewithEO_button;
    @FindBy(xpath = "//input[contains(@id,'continueWithNonAdviceOnlyNav')]")
    WebElement continuewithNonadvice_button;
    @FindBy(xpath = "//input[contains(@id,'continuebutton-nav')]")
    WebElement continue_button;
    @FindBy(xpath = "//input[@value='Confirm and continue']")
    WebElement confirm_button;
    @FindBy(xpath = "//input[contains(@id,'continuebutton-nav')]")
    WebElement continue2_button;
    @FindBy(xpath = "//h4[contains(text(),'created your username')]/../span")
    WebElement UserID_Agent;

    public What_would_you_like_to_do_Page(final WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void select_property(final WebDriver driver, final String propertytype) {
        if (propertytype.equalsIgnoreCase("Main Home")) {
            this.property_option1.click();
        } else if (propertytype.equalsIgnoreCase("Second Home")) {
            this.property_option2.click();
        } else if (propertytype.equalsIgnoreCase("BTL")) {
            this.property_option3.click();
        }
    }

    public void select_buyertype_mainhome(final WebDriver driver, final String propertytype, final String buyer_type) {
        if (propertytype.equalsIgnoreCase("Main Home")) {
            Select select = new Select(this.buyertype_mainhome);
            select.selectByVisibleText(buyer_type);
        } else if (propertytype.equalsIgnoreCase("Second Home")) {
            Select select = new Select(this.buyertype_secondhome);
            select.selectByVisibleText(buyer_type);
        } else if (propertytype.equalsIgnoreCase("BTL")) {
            Select select = new Select(this.buyertype_BTL_mainhome);
            select.selectByVisibleText(buyer_type);
        }

    }


    public void select_debtconsolidate(final WebDriver driver, final String propertytype, final String debtconsolidate) {
        if (propertytype.equalsIgnoreCase("main home")) {
            if (debtconsolidate.equalsIgnoreCase("yes")) {
                this.debtConsolidationMainHome_Yes.click();
            } else {
                this.debtConsolidationMainHome_No.click();
            }
        } else if (propertytype.equalsIgnoreCase("Second Home")) {
            if (debtconsolidate.equalsIgnoreCase("yes")) {
                this.debtConsolidationSecondHome_Yes.click();
            } else {
                this.debtConsolidationSecondHome_No.click();
            }
        }
    }
}
