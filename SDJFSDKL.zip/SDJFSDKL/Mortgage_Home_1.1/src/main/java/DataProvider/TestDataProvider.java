package DataProvider;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

import framework.Framework;

public class TestDataProvider extends Framework {

    public static int rowCount;

    @DataProvider(name = "Data1")
    public static Object[][] getData() throws Exception {
        String arrayExcelData[][] = null;
        Framework.dir = System.getProperty("user.dir");
        readExcel();
        int rows = getrowexecutioncount();
        arrayExcelData = new String[rows][Framework.rowCols - 3];

        int j = 0;
        for (TestDataProvider.rowCount = 1; TestDataProvider.rowCount <= Framework.rowCounttestCase; TestDataProvider.rowCount++) {

            fetchrowdata();
            if (gettestdata("RunStatus").toString().equalsIgnoreCase("Y")) {


                arrayExcelData[j][0] = gettestdata("Channel").toString();
                arrayExcelData[j][1] = gettestdata("Journey_Type").toString();
                arrayExcelData[j][2] = gettestdata("Property_Type").toString();
                arrayExcelData[j][3] = gettestdata("Joint_Applicant").toString();
                arrayExcelData[j][4] = gettestdata("Buyer_Type").toString();
                arrayExcelData[j][5] = gettestdata("Let_out_for_business").toString();
                arrayExcelData[j][6] = gettestdata("Salary").toString();
                arrayExcelData[j][7] = gettestdata("Repayment_Type").toString();
                arrayExcelData[j][8] = gettestdata("Number_of_Loans").toString();
                arrayExcelData[j][9] = gettestdata("Fee_Free").toString();
                arrayExcelData[j][10] = gettestdata("Loan_Type1").toString();
                arrayExcelData[j][11] = gettestdata("Loan_Type2").toString();
                arrayExcelData[j][12] = gettestdata("Loan_Type3").toString();
                arrayExcelData[j][13] = gettestdata("Loan_Type4").toString();
                arrayExcelData[j][14] = gettestdata("Loan_Type5").toString();
                arrayExcelData[j][15] = gettestdata("Loan_Type6").toString();

                j++;
            }
        }

        return arrayExcelData;

    }

    @DataProvider(name = "Data")
    public static Object[][] readdata() throws Exception {
        List<Map<String, Object>> main_map = new ArrayList<Map<String, Object>>();
        Framework.dir = System.getProperty("user.dir");
        readExcel();
        int rows = getrowexecutioncount();

        // ////////////////////////////////
        Map<String, Object> map = new HashMap<String, Object>(Framework.rowCols);
        for (TestDataProvider.rowCount = 1; TestDataProvider.rowCount <= Framework.rowCounttestCase; TestDataProvider.rowCount++) {

            FileInputStream file = new FileInputStream(new File(Framework.dir + "\\src\\main\\java\\TestData\\Testdata.xlsx"));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet spreadsheet = workbook.getSheet("Sheet1");
            Row rowtestCase = spreadsheet.getRow(rows);
            // System.out.println("######" + rowtestCase.getRowNum());

            XSSFRow row = null;

            row = spreadsheet.getRow(0);

            // if (rowtestCase.getCell(0).toString().equalsIgnoreCase("Y")) {

            for (int c = 0; c <= Framework.rowCols - 3; c++) {
                map.put(row.getCell(c).getStringCellValue(), rowtestCase.getCell(c).getStringCellValue());
            }

            file.close();

            main_map.add(map);
        }
        return new Object[][] {{main_map}};
    }
}
