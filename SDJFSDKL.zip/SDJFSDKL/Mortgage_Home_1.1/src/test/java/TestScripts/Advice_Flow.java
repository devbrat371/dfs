/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package TestScripts;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import DataProvider.TestDataProvider;
import PageObjectModel.Agent_Gateway_Page;
import PageObjectModel.Agent_Login_Page;
import PageObjectModel.Before_Your_Start_Page;
import PageObjectModel.Customer_Details_Page;
import PageObjectModel.Customer_Search_Result_Page;
import PageObjectModel.Present_at_Interview_Page;
import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Advice_Flow extends Framework {
    WebDriver driver;
    String Browser;
    String Channel;
    String Environment;
    Agent_Login_Page Agent_Login;
    Customer_Details_Page Customer_details;
    Customer_Search_Result_Page Customer_Search_Result;
    Agent_Gateway_Page agent_gateway;
    Present_at_Interview_Page Present_at_Interview;
    Before_Your_Start_Page Before_Your_Start;

    @BeforeTest
    @Parameters({"Browser", "Channel", "Environment"})
    public void Login(final String browser, final String channel, final String Env) throws Exception {
        this.Browser = browser;
        this.Channel = channel;
        this.Environment = Env;
    }

    @Test(dataProvider = "Data", dataProviderClass = TestDataProvider.class)
    /*
     * public void Advice_Flow_journey(final String channel, final String
     * Journey_Type, final String Property_Type, final String Joint_Applicant,
     * final String Buyer_Type, final String Let_out_for_business, final String
     * Salary, final String Repayment_Type, final String Number_of_Loans, final
     * String Fee_Free, final String Loan_Type1, final String Loan_Type2, final
     * String Loan_Type3, final String Loan_Type4, final String Loan_Type5,
     * final String Loan_Type6) throws Exception {
     */
    public void Advice_Flow_journey(final Map<String, Object> map) throws Exception {
        this.driver = Library.startSelenium(this.driver, this.Browser, this.Channel, this.Environment);

        this.Customer_details = new Customer_Details_Page(this.driver);
        this.Customer_details.search_newcustomer(this.driver);
        this.Customer_Search_Result = new Customer_Search_Result_Page(this.driver);
        this.Customer_Search_Result.select_new_customer(this.driver);
        this.Customer_details.add_customer(this.driver);
        this.agent_gateway = new Agent_Gateway_Page(this.driver);
        if (map.get("Joint_Applicant").toString().equalsIgnoreCase("Yes")) {
            this.agent_gateway.click_Add_Applicant(this.driver);
            this.Customer_details.search_newcustomer(this.driver);
            this.Customer_Search_Result.select_new_customer(this.driver);
            this.Customer_details.add_customer(this.driver);
        }
        this.agent_gateway.click_DIP_Button(this.driver);
        this.Present_at_Interview = new Present_at_Interview_Page(this.driver);
        this.Present_at_Interview.fill_present_at_interview(this.driver, map.get("Joint_Applicant").toString());
        this.Before_Your_Start = new Before_Your_Start_Page(this.driver);
        this.Before_Your_Start.fill_triage_response(this.driver);
        // this.driver.close();
    }
}
