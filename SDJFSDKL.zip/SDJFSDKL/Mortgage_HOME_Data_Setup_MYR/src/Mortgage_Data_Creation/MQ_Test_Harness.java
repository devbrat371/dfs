/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package Mortgage_Data_Creation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : MQ Test Harness Response Validation </b>
 * </p>
 */
public class MQ_Test_Harness extends Framework {
    public static void main(final String[] args) throws Exception {
        Framework.dir = System.getProperty("user.dir");
        String app_id = "313939930160726D";
        Library.Environment = "SIT";
        String Status = MQTestHarness(app_id);
        if (Status.equalsIgnoreCase("return code=0")) {
            System.out.println("Execution Complete");
            Display_Popup("Thank You!!!", "Return = 0");
        } else {
            System.out.println("Execution Failed");
        }
    }

    public static String MQTestHarness(final String appid) throws Exception {

        WebDriver driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        driver.get("https://hkgv2ls0074:Pr0tecthkgv2ls0074@www.hkgv2ls0074.p2g.netd2.hsbc.com.hk/1/2/");

        driver.findElement(By.xpath(getobjectdata("MQTest", "MQtestHarn"))).click();
        String s1 = null;
        if (Library.Environment.equalsIgnoreCase("UAT")) {
            s1 = "<soapenv:Envelope xmlns:soapenv=\"http://www.w3.org/2003/05/soap-envelope\"><soapenv:Header><ISMHdr ISMHdrVersNum=\"02.00\" RqstIndictr=\"Y\" ConsumerId=\"E1_MTP.U_GENSERV\" UserId=\"1103706519\" EmplyUserId=\"43335501\" GloblLogId=\"00:50:56:AA:03:BC_depunt-not-cfg\" MsgInstcId=\"1586\" UserDviceId=\"172.21.252.1\" MsgCreatTmspType=\"Z\" MsgCreatTmsp=\"2013-02-07T14:12:11.388000+00:00\" xmlns=\"http://ism.hsbc.com/ISMHdr/V2.0\"/><OpHdr OpDefCnt=\"1\" IgnrErrFlag=\"Y\" xmlns=\"http://ism.hsbc.com/OpHdr/V2.0\"><OpDefHdr seq=\"1\" SvceId=\"CNS_MtgeAdmin_001\" OpId=\"UpdHshldIncmExpn\" SvceVersNum=\"01.00\" OperVersNum=\"01.00\" OPUId=\"NA\"/><AppExtnsArea><AppExtnGrp seq=\"1\"><AppExtn item=\"1\" type=\"OH_SERVICE_HEADER\" UserData=\"0100000   OHI GBHBEU                          HSBC                          PFS       \"/><AppExtn item=\"2\" type=\"RCI_HEADER\" UserData=\"004292PKYZ143335501        400999             1           000\"/></AppExtnGrp></AppExtnsArea></OpHdr></soapenv:Header><soapenv:Body><RqstPayload><OpDefRqst seq=\"1\"><![CDATA[APLNHEADER00011MTUKEYSEGMENT0001";
        } else {
            s1 = "<soapenv:Envelope xmlns:soapenv=\"http://www.w3.org/2003/05/soap-envelope\"><soapenv:Header><ISMHdr ISMHdrVersNum=\"02.00\" RqstIndictr=\"Y\" ConsumerId=\"E1_MTP.D_SYSTEST\" UserId=\"1103706519\" EmplyUserId=\"43335501\" GloblLogId=\"00:50:56:AA:03:BC_depunt-not-cfg\" MsgInstcId=\"1586\" UserDviceId=\"172.21.252.1\" MsgCreatTmspType=\"Z\" MsgCreatTmsp=\"2013-02-07T14:12:11.388000+00:00\" xmlns=\"http://ism.hsbc.com/ISMHdr/V2.0\"/><OpHdr OpDefCnt=\"1\" IgnrErrFlag=\"Y\" xmlns=\"http://ism.hsbc.com/OpHdr/V2.0\"><OpDefHdr seq=\"1\" SvceId=\"CNS_MtgeAdmin_001\" OpId=\"UpdHshldIncmExpn\" SvceVersNum=\"01.00\" OperVersNum=\"01.00\" OPUId=\"NA\"/><AppExtnsArea><AppExtnGrp seq=\"1\"><AppExtn item=\"1\" type=\"OH_SERVICE_HEADER\" UserData=\"0100000   OHI GBHBEU                          HSBC                          PFS       \"/><AppExtn item=\"2\" type=\"RCI_HEADER\" UserData=\"004292PKYZ143335501        400999             1           000\"/></AppExtnGrp></AppExtnsArea></OpHdr></soapenv:Header><soapenv:Body><RqstPayload><OpDefRqst seq=\"1\"><![CDATA[APLNHEADER00011MTUKEYSEGMENT0001";
        }
        String s2 = "FUTRINC   0000FUTRXPEND 0000TMSTMPDETL000120130207141211388000SECPROGDTL0001VALOBTCM]]></OpDefRqst></RqstPayload></soapenv:Body></soapenv:Envelope>";

        String s3 = s1 + appid + s2;
        WebElement textarea = driver.findElement(By.xpath(getobjectdata("MQTest", "ReqStrng")));
        textarea.clear();
        textarea.sendKeys(s3);
        driver.findElement(By.xpath(getobjectdata("MQTest", "Response"))).click();

        driver.findElement(By.xpath(getobjectdata("MQTest", "HostMsg"))).click();

        String s4 = driver.findElement(By.xpath(getobjectdata("MQTest", "RespStrng"))).getText();

        String s5 = "RtrnCde=\"00\"";

        boolean b = s4.contains(s5);
        driver.close();
        if (b) {
            System.out.println("***********Return Code = 0**************");
            return "return code=0";
        } else {
            System.out.println("******Retrurn Code not Equal to 0*************");
            Display_Popup("Error!!!", "Return Code not Equal to 0");
            return "return code not equal to 0";
        }
    }
}
