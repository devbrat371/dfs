/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package Mortgage_Data_Creation;

import org.testng.annotations.Test;

import End_to_End_Flow.Agent_Advised_Journey;
import End_to_End_Flow.Agent_EO_Journey;
import End_to_End_Flow.Agent_NonAdvised_Journey;
import End_to_End_Flow.Customer_Advised_Journey;
import End_to_End_Flow.Customer_EO_Journey;
import End_to_End_Flow.Customer_NonAdvised_Journey;
import End_to_End_Flow.Existing_Agent_Advised_Journey;
import End_to_End_Flow.Existing_Agent_EO_Journey;
import End_to_End_Flow.Existing_Agent_Non_Advised_Journey;
import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class E2E_Test extends Framework {
    public static int rowCount;
    public static int counter;
    public static String existing_mortgage = null;
    public static String Final_rate = null;
    public static String Account_number = null;

    @Test
    public void Data_Creation() throws Exception {
        System.out.println("###End to End Journey###");
        // Library.Environment = Env;
        // Library.url = url;
        Framework.dir = System.getProperty("user.dir");
        readExcel();
        for (E2E_Test.rowCount = 1; E2E_Test.rowCount <= Framework.rowCounttestCase; E2E_Test.rowCount++) {
            E2E_Test.counter = 0;
            fetchrowdata();
            System.out.println("RunStatus:" + (gettestdata("RunStatus")));
            if (gettestdata("RunStatus").toString().equalsIgnoreCase("Y")) {
                Library.Environment = gettestdata("Environment");
                Library.url = gettestdata("URL");
                if (gettestdata("Channel").toString().equalsIgnoreCase("Agent")) {

                    if (gettestdata("Journey_Type").toString().equalsIgnoreCase("Advised")) {
                        if (gettestdata("Flow").toString().equalsIgnoreCase("Manage_Flow")) {
                            Existing_Agent_Advised_Journey.Existing_Agent_Advised_Flow();
                        } else {
                            Agent_Advised_Journey.Agent_Advised_Flow();
                        }
                    }
                    if (gettestdata("Journey_Type").toString().equalsIgnoreCase("Non-Advised")) {
                        if (gettestdata("Flow").toString().equalsIgnoreCase("Manage_Flow")) {
                            Existing_Agent_Non_Advised_Journey.Existing_Agent_Non_Advised_Flow();
                        } else {
                            Agent_NonAdvised_Journey.Agent_NonAdvised_Flow();
                        }
                    }
                    if (gettestdata("Journey_Type").toString().equalsIgnoreCase("EO")) {
                        if (gettestdata("Flow").toString().equalsIgnoreCase("Manage_Flow")) {
                            Existing_Agent_EO_Journey.Existing_Agent_EO_Flow();
                        } else {
                            Agent_EO_Journey.Agent_EO_Flow();
                        }
                    }
                } else if (gettestdata("Channel").toString().equalsIgnoreCase("Customer")) {
                    if (gettestdata("Journey_Type").toString().equalsIgnoreCase("EO")) {
                        Customer_EO_Journey.Customer_EO_Flow();
                    }
                    if (gettestdata("Journey_Type").toString().equalsIgnoreCase("Non-Advised")) {
                        Customer_NonAdvised_Journey.Customer_NonAdvised_Flow();
                    }
                    if (gettestdata("Journey_Type").toString().equalsIgnoreCase("Advised")) {
                        Customer_Advised_Journey.Customer_Advised_Flow();
                    }
                }
            } else if (gettestdata("RunStatus").toString().equalsIgnoreCase("N")) {
                update_Result(E2E_Test.rowCount, "NO RUN");
            }
        }
    }
}
