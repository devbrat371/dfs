/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package Common_Library;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Common_Functions extends Framework {
    public static void search_Customer() throws Exception {
        Select select = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "title"))));
        select.selectByVisibleText("Mr");

        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "first_name"))).sendKeys(
            "MYR" + get_random_char(5));
        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "last_name"))).sendKeys(
            "Test" + get_random_char(5));
        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "date"))).sendKeys("04");
        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "month"))).sendKeys("10");
        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "year"))).sendKeys("1981");

        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "gender"))).click();

        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "application_search"))).click();

        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "non_of_the_above_rad_button"))).click();
        Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "confirm"))).click();
    }

    public static void Add_Customer() throws Exception {
        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "home_telephone_intl"))).sendKeys("+0111");

        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "home_telephone_std"))).sendKeys("1111111");
        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "home_telephone_number"))).sendKeys("1111");

        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "mobile_telephone_intl"))).sendKeys("+011");
        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "mobile_telephone_std"))).sendKeys("1111");
        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "mobile_telephone_number"))).sendKeys("11111");

        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "email"))).sendKeys(
            "MYR" + get_random_char(5) + "@HSBC.com");

        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "postcode"))).sendKeys("S1 3GG");

        boolean add_flag = true;
        while (add_flag) {
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "find_address"))).click();

                Select select1_1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page",
                    "address_list_box"))));
                select1_1.selectByIndex(1);
                add_flag = false;
            } catch (Exception e) {
                add_flag = true;
            }
        }

        Select selectYears = new Select(Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page",
            "years_at_currentaddress"))));
        selectYears.selectByVisibleText("9");
        Select selectMonths = new Select(Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page",
            "months_at_currentaddress"))));

        selectMonths.selectByVisibleText("11");
        Framework.driver.findElement(By.xpath(getobjectdata("ADD_Customer_Page", "save"))).click();

    }

    public static void Fill_NTB_GAD1_PersonalDetails() throws Exception {
        Thread.sleep(1000);

        Select selectcurrentLiving = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "Residential_Status"))));
        selectcurrentLiving.selectByVisibleText("Live in a property I own");

        Select selectStatus = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "Marital_dropdown"))));
        Library.select_dropdown(selectStatus, "Single");

        Select selectDependent = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "No_of_dependent"))));
        Library.select_dropdown(selectDependent, "0");

        Select selectcountryresidence = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
            "GAD1_Personal_Details_Page", "Country"))));
        try {

            Library.select_dropdown(selectcountryresidence, "United Kingdom Of Great Britain And Northern Ireland");

        } catch (Exception e) {
            Library.select_dropdown(selectcountryresidence, "United Kingdom");

        }

        Select selectnationality = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "Nationality"))));
        try {

            Library.select_dropdown(selectnationality, "United Kingdom Of Great Britain And Northern Ireland");

        } catch (Exception e) {
            Library.select_dropdown(selectnationality, "United Kingdom");

        }

        /*
         * if (!(selectnationalitye.getFirstSelectedOption().getText().
         * equalsIgnoreCase("United Kingdom"))) { Framework.driver.findElement
         * (By.xpath(getobjectdata("GAD1_Personal_Details_Page",
         * "rightToAbode_no"))).click(); }
         */
        try {
            Select selectByutoLet = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                "Other_resident"))));
            Library.select_dropdown(selectByutoLet, "None");
        } catch (Exception e) {
        }
        WebElement work_phone_int = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "Work_Phone_int")));
        Library.enter_data(work_phone_int, "+111");
        WebElement work_phone_std = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "Work_Phone_std")));
        Library.enter_data(work_phone_std, "1111111");
        WebElement work_phone_number = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "Work_Phone_number")));
        Library.enter_data(work_phone_number, "11111111");
        Select selectAddressco1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "correnspodence_dropdown"))));
        Library.selectbyIndex_dropdown(selectAddressco1, 1);
        Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "issue_doc_via_other_option"))).click();
        Select selectReminderSent = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
            "Send_Reminder"))));
        Library.select_dropdown(selectReminderSent, "By post");
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Select_marketing_format"))).click();
        } catch (Exception e) {
        }
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Send_Reminder_other_format_no")))
                .click();
        } catch (Exception e) {
        }
        Framework.log_report("PASS", "GAD1 Personal Details Complete", "Yes");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Continue"))).click();

    }

    public static void Fill_NTB_GAD1_FinancialDetails() throws Exception {

        Select selectEmployment = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Emp_Status"))));
        // Library.selectbyIndex_dropdown(selectEmployment, 2);
        Library.select_dropdown(selectEmployment, "Employed - full time");

        try {

            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Graduation_Year")))
                .isDisplayed()) {

                WebElement grad_year = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Graduation_Year")));
                if (grad_year.getAttribute("Value").equalsIgnoreCase("")) {
                    grad_year.clear();
                    Thread.sleep(1000);
                    grad_year.sendKeys("2000");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "comp_director_no")))
                .isDisplayed()) {

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "comp_director_no"))).click();
            }
        } catch (Exception e) {
        }
        try {
            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Emp_Business"))).isDisplayed()) {

                Select selectWorkingArea = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Financial_Details_Page", "Emp_Business"))));
                Library.select_dropdown(selectWorkingArea, "Computers & Telecommunications");


                Select selectOccupation = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Financial_Details_Page", "Occupation_Type"))));
                Library.select_dropdown(selectOccupation, "Manual - Supervisory");

                Select selectSepcificOCC = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Financial_Details_Page", "Specific_occupation"))));
                Library.select_dropdown(selectSepcificOCC, "Agricultural worker");
                if (Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Job_Title"))).isDisplayed()) {
                    WebElement jobtitle = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Job_Title")));
                    Library.enter_data(jobtitle, "audsjhidbq");
                }
                WebElement empstartdate = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Emp_Startdate_Day")));
                if (empstartdate.getAttribute("Value").equalsIgnoreCase("")) {
                    empstartdate.clear();
                    empstartdate.sendKeys("10");
                }
                WebElement empstartmonth = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Emp_Startdate_Month")));
                if (empstartmonth.getAttribute("Value").equalsIgnoreCase("")) {
                    empstartmonth.clear();
                    empstartmonth.sendKeys("05");
                }

                WebElement empstartyear = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Emp_Startdate_Year")));
                if (empstartyear.getAttribute("Value").equalsIgnoreCase("")) {
                    empstartyear.clear();
                    empstartyear.sendKeys("2000");
                }
            }
        } catch (Exception e) {
        }
        try {

            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "other_employment_no")))
                .isDisplayed()) {

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "other_employment_no"))).click();
            }
        } catch (Exception e) {
        }
        try {
            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Income_Frequency")))
                .isDisplayed()) {
                Select selectPaidTIME = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Financial_Details_Page", "Income_Frequency"))));
                if (gettestdata("Channel").equalsIgnoreCase("Agent")) {
                    Library.select_dropdown(selectPaidTIME, "Every month");
                } else {
                    selectPaidTIME.selectByVisibleText("Monthly");
                }
            }
        } catch (Exception e) {
        }
        Select selectPaidBY = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Income_Method"))));
        Library.select_dropdown(selectPaidBY, "Direct to Bank / BACS");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income"))).clear();

        Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income"))).sendKeys(
            gettestdata("Salary"));


        WebElement otherincome = Framework.driver.findElement(By
            .xpath(getobjectdata("GAD1_Financial_Details_Page", "Other_Income")));
        Library.enter_data(otherincome, "200");

        Select selectBank = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Time_with_Bank_Years"))));
        selectBank.selectByVisibleText("10");

        Select selectBankmm = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Time_with_Bank_Month"))));
        selectBankmm.selectByVisibleText("10");

        Select selectDC = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Number_of_Debit_cards"))));
        Library.select_dropdown(selectDC, "1");

        Select selectCC = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Number_of_Credit_cards"))));
        Library.select_dropdown(selectCC, "1");


        WebElement outstanding = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Outstanding_balance")));
        Library.enter_data(outstanding, "0");
        WebElement monthlyloan = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
            "Total_monthly_loan")));
        Library.enter_data(monthlyloan, "0");
        Framework.log_report("PASS", "GAD1 Financial Details Complete", "Yes");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Continue"))).click();
    }

    public static void Fill_NTB_GAD2_PersonalDetails() throws Exception {
        WebElement mothername = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "Mothers_Name")));
        Library.enter_data(mothername, "sdfjndj");
        /*
         * if (Library.url.equalsIgnoreCase("eu461")) { Select birth_country =
         * new Select(Framework.driver.findElement(By.xpath(getobjectdata(
         * "GAD2_Personal_Details_Page", "country_of_birth"))));
         * Library.select_dropdown(birth_country, "United Kingdom");
         * Framework.driver
         * .findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
         * "existing_relationship_hsbc_no"))) .click(); }
         */
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "Public_Official_opt1"))).click();
        if (gettestdata("Journey_Type").equalsIgnoreCase("Non-Advised")) {
            Select no_of_BTL = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
                "No_of_BTL"))));
            no_of_BTL.selectByVisibleText("None");
        }

        if (gettestdata("URL").equalsIgnoreCase("eu474") || gettestdata("URL").equalsIgnoreCase("eu461")) {
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "anothername"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "previousname"))).click();

            Select selectprevtitle = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
                "previoustitle"))));
            selectprevtitle.selectByVisibleText("Mr");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "previousfirstname"))).sendKeys(
                "MYR" + get_random_char(5));

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "previoussurname"))).sendKeys(
                "MYR" + get_random_char(5));

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "haspreviousname"))).click();
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "hasrelationship"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "relationshipHSBCUK"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "relationshipHSBCnotUK")))
                    .click();


                Select selectothercountriescount = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD2_Personal_Details_Page", "otherCountriescount"))));
                selectothercountriescount.selectByVisibleText("2");

                Select selectothercountriesdrop1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD2_Personal_Details_Page", "otherCountriesdrop1"))));
                selectothercountriesdrop1.selectByVisibleText("Peru");

                Select selectothercountriesdrop2 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD2_Personal_Details_Page", "otherCountriesdrop2"))));
                selectothercountriesdrop2.selectByVisibleText("Singapore");
            } catch (Exception e) {
            }
            Select selectcountryofbirth = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                "GAD2_Personal_Details_Page", "birthcountry"))));
            selectcountryofbirth.selectByVisibleText("United Kingdom Of Great Britain And Northern Ireland");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "nationalityradio"))).click();

            Select selectadditionalnationality1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                "GAD2_Personal_Details_Page", "nationalitydrop1"))));
            selectadditionalnationality1.selectByVisibleText("Australia");

            Select selectadditionalnationality2 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                "GAD2_Personal_Details_Page", "nationalitydrop2"))));
            selectadditionalnationality2.selectByVisibleText("Fiji");

            try {
                Select s_years = new Select(Framework.driver.findElement(By
                    .xpath("//Select[contains(@id,'yearsatpreviousaddress1')]")));
                s_years.selectByVisibleText("10");
                Select s_months = new Select(Framework.driver.findElement(By
                    .xpath("//Select[contains(@id,'monthsatpreviousaddress1')]")));
                s_months.selectByVisibleText("10");
            } catch (Exception E) {
            }
        }
        Framework.log_report("PASS", "GAD2 Personal Details Complete", "Yes");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "continue"))).click();
    }

    public static void Fill_NTB_GAD2_FinancialDetails() throws Exception {
        WebElement compname = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Company_Name")));
        Library.enter_data(compname, "HSBC");

        try {

            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Course_Due_Day")))
                .isDisplayed()) {

                WebElement courseDueDay = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Course_Due_Day")));
                if (courseDueDay.getAttribute("Value").equalsIgnoreCase("")) {
                    courseDueDay.clear();
                    courseDueDay.sendKeys("10");
                }

                WebElement courseDueMonth = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Course_Due_Month")));
                if (courseDueMonth.getAttribute("Value").equalsIgnoreCase("")) {
                    courseDueMonth.clear();
                    courseDueMonth.sendKeys("10");
                }

                WebElement courseDueYear = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Course_Due_Year")));
                if (courseDueYear.getAttribute("Value").equalsIgnoreCase("")) {
                    courseDueYear.clear();
                    courseDueYear.sendKeys("2018");
                }
            }
        } catch (Exception e) {

        }


        WebElement comppost = Framework.driver.findElement(By
            .xpath(getobjectdata("GAD2_Financial_Details_Page", "Company_Postcode")));
        Library.enter_data(comppost, "S1 3GG");
        if (Library.prefilled_flag == false) {
            boolean add_flag = true;
            while (add_flag) {
                try {
                    if (Framework.driver
                        .findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Company_find_address"))).isDisplayed()) {

                        Framework.driver
                            .findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Company_find_address"))).click();
                        Select selectBuilder = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                            "GAD2_Financial_Details_Page", "Company_address_listbox"))));
                        // selectBuilder.selectByVisibleText("S2 3GG,76,Heeley Bank Road,Sheffield,");
                        selectBuilder.selectByIndex(1);
                        add_flag = false;
                    }
                } catch (Exception E) {
                    add_flag = true;
                }
            }
        }

        Select selectPaid = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
            "Income_frequency"))));
        Library.select_dropdown(selectPaid, "Every month");

        Select selectPaidinBank = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
            "Income_Method"))));
        Library.select_dropdown(selectPaidinBank, "Direct to Bank / BACS");

        // driver.findElement(By.id("viewns_7_ULDKAB1A08DL90AETC226SH952_:financialdetai1form:grossannualincometextbox-field")).sendKeys("20000");

        WebElement Bonus = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Bonus_income")));
        Library.enter_data(Bonus, "20");
        // driver.findElement(By.id("viewns_7_ULDKAB1A08DL90AETC226SH952_:financialdetai1form:otherincometextbox-field")).sendKeys("20");
        // Added try catch
        try {

            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Retirement_Age")))
                .isDisplayed()) {

                WebElement ret_age = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Retirement_Age")));
                Library.enter_data(ret_age, "85");
            }
        } catch (Exception e) {
        }
        try {

            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Confirm_radio_button")))
                .isDisplayed()) {

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Confirm_radio_button")))
                    .click();

                Framework.driver.findElement(
                    By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Employment_pending_changes_radiobutton"))).click();
            }
        } catch (Exception e) {
        }
        // Added try catch
        try {

            if (Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Permanent_Emp_Radiobutton")))
                .isDisplayed()) {


                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Permanent_Emp_Radiobutton")))
                    .click();
            }
        } catch (Exception e) {

        }

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Dividend_Annual_Income")))
            .sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "StateBenifit_Annual_Income")))
            .sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Annual_Investment"))).sendKeys("0");

        Select selectAccount = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
            "bank_dropdown"))));
        Library.select_dropdown(selectAccount, "Other");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Current_Account_with_other"))).click();

        Select selectDebitCard = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
            "number_of_Debitcard"))));
        Library.select_dropdown(selectDebitCard, "1");


        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "number_of_Creditcard"))).sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "counsil_tax"))).sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "utilities"))).sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "buildinginsurance"))).sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "otherinsurance"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "assurancecosts"))).sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "savingsandinvestmentcost"))).sendKeys(
            "0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "pension"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "intend_to_repay"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "ground_rent"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "essential_travel_costs")))
            .sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "non_essential_travel_cost"))).sendKeys(
            "0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "housekeeping"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "packagecost"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "childmaintainance"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "alimony_costs"))).sendKeys("0");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "child_care_costs"))).sendKeys("0");

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "school_college_fees"))).sendKeys("0");
        Framework.log_report("PASS", "GAD2 Financial Details Complete", "Yes");
        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "continue1_button"))).click();
        if (!(gettestdata("Referrence_App_ID").equalsIgnoreCase("NA"))) {
            try {
                List<WebElement> l = Framework.driver.findElements(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "how_to_pay")));
                // System.out.println(l.size() +
                // "****************************************");
                for (int i = 0; i < l.size(); i++) {
                    Thread.sleep(1000);
                    Select how_to_pay = new Select(l.get(i));
                    try {
                        how_to_pay.selectByVisibleText("No,I won't pay this");
                    } catch (Exception e) {
                        how_to_pay.selectByVisibleText("No, I won't pay this");
                    }
                    // System.out.println("i=" + i);
                }
            } catch (Exception e) {
                System.out.println("Inside catch");
                e.printStackTrace();
            }
        }

        Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "continue2_button"))).click();

    }

    public static void Complete_Valuation() throws Exception {
        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "Select_Home_Buyer"))).click();

        Select selectWho = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "relation"))));
        selectWho.selectByVisibleText("Other");

        Select selectPersonAgent = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "title"))));
        selectPersonAgent.selectByVisibleText("Mr");

        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "firstname"))).sendKeys("MTSHFSDN");

        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "lastname"))).sendKeys("Mshahsaj");

        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "homephonestd"))).sendKeys("566");

        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "homephonenum"))).sendKeys("5484145");

        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "mobilephonestd"))).sendKeys("454");
        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "mobilephonenum"))).sendKeys("5484145");
        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "email"))).sendKeys("fewiew@HSBC.com");

        Select selectContact = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "bestcontact"))));
        selectContact.selectByVisibleText("By phone");
        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "propertyaddr"))).click();

        Framework.driver.findElement(By.id("additionalcommenttextarea-field")).sendKeys("ok done");

        Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "Continue"))).click();
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "Continue"))).click();
        } catch (Exception e) {
        }
        Framework.log_report("PASS", "Valuation Complete", "Yes");
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "Confirm_and_Continue"))).click();
        } catch (Exception e) {
        }
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "ValConfirm"))).click();
        } catch (Exception e) {
        }
    }

    public static void Complete_ConveyancingDetails() throws Exception {
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("Conveyancing", "managed_pannel_continue"))).click();
        } catch (Exception e) {
            Framework.driver.findElement(By.xpath(getobjectdata("Conveyancing", "panelsol"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("Conveyancing", "hsbcpanelsol"))).click();
        }
        Framework.log_report("PASS", "Conveyancing Details Complete", "Yes");
        Framework.driver.findElement(By.xpath(getobjectdata("Conveyancing", "continue"))).click();
    }

    public static void Complete_DD() throws Exception {
        Framework.driver.findElement(By.xpath(getobjectdata("DD", "accholder"))).sendKeys(get_random_char(5));

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "accnum"))).sendKeys("46065024");

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "rollnum"))).sendKeys("451");

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "sortcodefirst"))).sendKeys("60");

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "sortcodesec"))).sendKeys("13");

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "sortcodethird"))).sendKeys("23");

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "payment"))).sendKeys("12");

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "confirmcheck"))).click();

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "continue"))).click();

        Framework.driver.findElement(By.xpath(getobjectdata("DD", "confirmcontinue"))).click();
        Framework.log_report("PASS", "DD Complete", "Yes");
        Framework.driver.findElement(By.xpath(getobjectdata("DD", "continue"))).click();

    }

    public static void Complete_Application_Maintenance() throws Exception {
        Framework.driver.findElement(By.xpath(getobjectdata("Application Maintenance", "JmsAppMain"))).click();

        List<WebElement> eviddoc = Framework.driver.findElements(By.xpath(getobjectdata("Application Maintenance", "EvidDocs")));
        for (int i = 0; i < eviddoc.size(); i++) {
            Select selecteviddocs = new Select(eviddoc.get(i));
            selecteviddocs.selectByVisibleText("Received");
        }

        Select selectCheck;

        try {
            List<WebElement> Identification = Framework.driver.findElements(By.xpath(getobjectdata("Application Maintenance",
                "Identification")));
            for (int i = 0; i < Identification.size(); i++) {
                selectCheck = new Select(Identification.get(i));
                selectCheck.selectByVisibleText("Completed");
            }
        } catch (Exception e) {
        }
        try {
            List<WebElement> Imperson = Framework.driver.findElements(By
                .xpath(getobjectdata("Application Maintenance", "Imperson")));
            for (int i = 0; i < Imperson.size(); i++) {
                selectCheck = new Select(Imperson.get(i));
                selectCheck.selectByVisibleText("Completed");
            }
        } catch (Exception E) {
        }
        // selectCheck.selectByVisibleText("Completed");
        try {
            if (Framework.driver.findElement(By.xpath(getobjectdata("Application Maintenance", "confirmSegmentEligibility")))
                .isDisplayed()
                || Framework.driver.findElement(By.xpath(getobjectdata("Application Maintenance", "confirmSegmentEligibility")))
                    .isEnabled()) {
                Framework.driver.findElement(By.xpath(getobjectdata("Application Maintenance", "confirmSegmentEligibility")))
                    .click();
            }
        } catch (Exception e) {
        }
        Framework.log_report("PASS", "Application Maintenance Complete", "Yes");
        Framework.driver.findElement(By.xpath(getobjectdata("Application Maintenance", "Confirm"))).click();

    }

    public static void Complete_Document_and_Correspondence() throws Exception {
        Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "DocsCorresp"))).click();

        List<WebElement> dropdown = Framework.driver.findElements(By.xpath(getobjectdata("DocsCorres", "DocStatus")));


        for (int i = 0; i < dropdown.size(); i++) {
            Select docvalidation = new Select(dropdown.get(i));
            docvalidation.selectByVisibleText("Validated");
        }

        Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "Save"))).click();
        Framework.log_report("PASS", "Document and Correspondence Complete", "Yes");

        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();

    }

    public static void Pay_Fees() throws Exception {
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "PayNow"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "SelectAll"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "StaffCont"))).click();

            WebElement selectpayment = Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardselMenu")));
            Select s = new Select(selectpayment);
            s.selectByVisibleText("Add card");

            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardSelButton"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Postcode"))).sendKeys("S1 3GG");
            boolean add_flag = true;
            while (add_flag) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "FindAddr"))).click();
                    Select selectbillingAddress = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees",
                        "AddrList"))));
                    selectbillingAddress.selectByIndex(1);
                    add_flag = false;
                } catch (Exception e) {
                    add_flag = true;
                }
            }
            Select selectcard = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardType"))));
            selectcard.selectByVisibleText("Visa");

            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Name"))).sendKeys("abc");
            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardNum"))).sendKeys("4012001037141112");

            Select expmonth = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "ExpMon"))));
            expmonth.selectByVisibleText("01");

            Select expyear = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "ExpYear"))));
            expyear.selectByVisibleText("18");

            Select startmonth = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "StartMon"))));
            startmonth.selectByVisibleText("01");

            Select startyear = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "StartYear"))));
            startyear.selectByVisibleText("14");

            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CVS"))).sendKeys("111");
            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "AddNew"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Continue"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Confirm"))).click();
            Framework.log_report("PASS", "Payment Complete", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "SaveContinue"))).click();


        } catch (Exception e) {

        }
    }

    public static void Joint_Applicant_Confirmation() throws Exception {
        try {
            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "joint_app_radio"))).click();
        } catch (Exception e) {
            if (Library.Environment.equalsIgnoreCase("UAT")) {

                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "joint_app_radio"))).click();
        }
        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "refresh_page"))).click();
        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "jms_next_step"))).click();

        Framework.driver.findElement(By.xpath(getobjectdata("Joint_Applicant", "confirm_joint_app_details"))).click();
        try {
            if (Library.Environment.equalsIgnoreCase("UAT")) {

                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
            }
        } catch (Exception E) {
            if (Library.Environment.equalsIgnoreCase("UAT")) {

                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
            }
        }

        String parent = Framework.driver.getWindowHandle();
        Framework.driver.findElement(By.xpath(getobjectdata("Joint_Applicant", "init_disclosure_doc"))).click();
        Thread.sleep(5000);
        Framework.driver.switchTo().window(parent);
        Thread.sleep(1000);
        Framework.driver.findElement(By.xpath(getobjectdata("Joint_Applicant", "continue"))).click();
    }

    public static void Fill_Customer_Details() throws Exception {
        Select select = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "Title"))));
        select.selectByVisibleText("Mr");

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "First_Name"))).sendKeys(
            "MYR" + get_random_char(5));
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "Last_Name"))).sendKeys(
            "Test" + get_random_char(5));
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "dob_date"))).sendKeys("21");
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "dob_month"))).sendKeys("03");
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "dob_year"))).sendKeys("1988");

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "gender_male"))).click();

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "home_telephone_intl"))).sendKeys("+0111");

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "home_telephone_std"))).sendKeys("1111111");
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "home_telephone_number"))).sendKeys("1111");

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "mobile_telephone_intl"))).sendKeys("+011");
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "mobile_telephone_std"))).sendKeys("1111");
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "mobile_telephone_number"))).sendKeys("11111");

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "email"))).sendKeys(
            "MYR" + get_random_char(5) + "@HSBC.com");

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "postcode"))).sendKeys("S1 3GG");

        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "find_address"))).click();

        Select select1 = new Select(Framework.driver.findElement(By
            .xpath(getobjectdata("Who_is_Applying_Page", "address_list_box"))));
        select1.selectByIndex(1);

        Select selectYears = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page",
            "years_at_currentaddress"))));
        selectYears.selectByVisibleText("9");
        Select selectMonths = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page",
            "months_at_currentaddress"))));

        selectMonths.selectByVisibleText("11");
        Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "continue"))).click();
    }

    public static void Security_Details() throws Exception {
        Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details", "password"))).sendKeys("111222333");
        Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details", "conf_passowrd"))).sendKeys("111222333");

        Select memorable_qustn = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details",
            "memorable_qustn"))));
        memorable_qustn.selectByIndex(1);

        Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details", "answer"))).sendKeys("hsbcbank");
        Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details", "conf_answer"))).sendKeys("hsbcbank");

        Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details", "Save_and_Continue"))).click();
        String Username = Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details", "user_id"))).getText();
        System.out.println("***Username : " + Username);
        update_UserID(Mortgage_Data_Creation.E2E_Test.rowCount, Username);
        Framework.driver.findElement(By.xpath(getobjectdata("Your_Security_Details", "Save_and_Continue2"))).click();

    }

    public static void Pay_Fees_Customer() throws Exception {
        try {
            if (gettestdata("Environment").equalsIgnoreCase("SIT")) {
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "PayNow"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "SelectAll"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Customer_Cont"))).click();

                WebElement selectpayment = Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardselMenu")));
                Select s = new Select(selectpayment);
                s.selectByVisibleText("Add card");

                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardSelButton"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Postcode"))).sendKeys("S1 3GG");

                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "FindAddr"))).click();


                Select selectbillingAddress = new Select(Framework.driver.findElement(By
                    .xpath(getobjectdata("PayFees", "AddrList"))));
                selectbillingAddress.selectByIndex(1);

                Select selectcard = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardType"))));
                selectcard.selectByVisibleText("Visa");

                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Name"))).sendKeys("abc");
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CardNum"))).sendKeys("4012001037141112");

                Select expmonth = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "ExpMon"))));
                expmonth.selectByVisibleText("01");

                Select expyear = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "ExpYear"))));
                expyear.selectByVisibleText("18");

                Select startmonth = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "StartMon"))));
                startmonth.selectByVisibleText("01");

                Select startyear = new Select(Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "StartYear"))));
                startyear.selectByVisibleText("14");

                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "CVS"))).sendKeys("111");
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "AddNew"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Continue"))).click();
                try {
                    Framework.driver.findElement(By.xpath("//input[@value='Submit']")).click();
                } catch (Exception E) {
                }
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Confirm"))).click();
                Framework.log_report("PASS", "Payment Complete", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "SaveContinue_Customer"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("PayFees", "Continue_Customer"))).click();
            }
        } catch (Exception E) {
        }
    }

}
