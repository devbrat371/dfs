/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package framework;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Library extends Framework {
    public static String Environment;
    public static String url;
    public static boolean HOL_Flag = false;

    // public static boolean HC_Flag = false;

    public static void startSelenium(final String Channel) throws Exception {
        Framework.dir = System.getProperty("user.dir");
        String browser = getConfigData("Browser");

        if (browser.equalsIgnoreCase("Firefox")) {

            final String firebugPath = "C://SWDTOOLS//Selenium//firepath//firebug-1.12.8.xpi";
            final String firebugPath1 = "C://SWDTOOLS//Selenium//firepath//firepath-0.9.7.1-fx.xpi";

            FirefoxProfile profile = new FirefoxProfile();
            profile.addExtension(new File(firebugPath));
            profile.addExtension(new File(firebugPath1));

            Framework.driver = new FirefoxDriver(profile);
            atu.testng.reports.ATUReports.setWebDriver(Framework.driver);

            if (Channel.equalsIgnoreCase("Agent_Channel")) {
                if (Library.Environment.equalsIgnoreCase("SIT")) {
                    if (Library.url.equalsIgnoreCase("hk341")) {
                        Framework.driver.get(getConfigData("SIT_Agent_URL1_hk341"));

                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("SIT_Agent_UserID_hk341"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("SIT_Agent_Password_hk341"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("SIT_Agent_URL2_hk341"));
                    }
                    if (Library.url.equalsIgnoreCase("eu461")) {
                        Framework.driver.get(getConfigData("SIT_Agent_URL1_eu461"));

                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("SIT_Agent_UserID_eu461"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("SIT_Agent_Password_eu461"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("SIT_Agent_URL2_eu461"));
                    }
                    if (Library.url.equalsIgnoreCase("eu425")) {
                        Framework.driver.get(getConfigData("SIT_Agent_URL1_eu425"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("SIT_Agent_UserID_eu425"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("SIT_Agent_Password_eu425"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("SIT_Agent_URL2_eu425"));
                    }
                } else if (Library.Environment.equalsIgnoreCase("DIT")) {
                    if (Library.url.equalsIgnoreCase("eu463")) {
                        Framework.driver.get(getConfigData("DIT_Agent_URL1_eu463"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("DIT_Agent_UserID_eu463"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("DIT_Agent_Password_eu463"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("DIT_Agent_URL2_eu463"));
                    }
                } else if (Library.Environment.equalsIgnoreCase("UAT")) {
                    if (Library.url.equalsIgnoreCase("hk342")) {
                        Framework.driver.get(getConfigData("UAT_Agent_URL1_hk342"));
                        Framework.driver.findElement(By.xpath("//a[text()='Custom Home Logon']")).click();
                        Framework.driver.findElement(By.xpath("//input[contains(@id,'customLogin:userId')]")).sendKeys(
                            getConfigData("UAT_Agent_UserID_hk342"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath("//input[contains(@id,'customLogin:password')]")).sendKeys(
                            getConfigData("UAT_Agent_Password_hk342"));
                        Framework.driver.findElement(By.xpath("//input[@value='Login']")).click();
                        Framework.driver.get(getConfigData("UAT_Agent_URL2_hk342"));
                    }
                    if (Library.url.equalsIgnoreCase("hk404")) {
                        Framework.driver.get(getConfigData("UAT_Agent_URL1_hk404"));
                        Framework.driver.findElement(By.xpath("//a[text()='Custom Home Logon']")).click();
                        Framework.driver.findElement(By.xpath("//input[contains(@id,'customLogin:userId')]")).sendKeys(
                            getConfigData("UAT_Agent_UserID_hk404"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath("//input[contains(@id,'customLogin:password')]")).sendKeys(
                            getConfigData("UAT_Agent_Password_hk404"));
                        Framework.driver.findElement(By.xpath("//input[@value='Login']")).click();
                        Framework.driver.get(getConfigData("UAT_Agent_URL2_hk404"));
                    }
                }
            } else if (Channel.equalsIgnoreCase("Customer_Channel")) {

                Windows_Login_1 wl = new Windows_Login_1();
                Windows_Login_2 tt1 = new Windows_Login_2(wl, "FirstLogin");
                if (Library.Environment.equalsIgnoreCase("SIT")) {
                    if (Library.url.equalsIgnoreCase("hk74")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("SIT_Customer_URL_hk74"));
                    }
                    if (Library.url.equalsIgnoreCase("hk375")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("SIT_Customer_URL_hk375"));
                    }
                    if (Library.url.equalsIgnoreCase("eu474")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("SIT_Customer_URL_eu474"));
                    }
                } else if (Library.Environment.equalsIgnoreCase("DIT")) {
                    if (Library.url.equalsIgnoreCase("eu450")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("DIT_Customer_URL_eu450"));
                        Library.url = getConfigData("DIT_Customer_URL_eu450");
                    }
                } else if (Library.Environment.equalsIgnoreCase("UAT")) {
                    if (Library.url.equalsIgnoreCase("hk72")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("UAT_Customer_URL_hk72"));
                        Library.url = getConfigData("UAT_Customer_URL_hk72");
                    }
                }
            }
            Framework.driver.manage().window().maximize();
            Framework.driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

        }

        if (browser.equalsIgnoreCase("Chrome")) {
            System.setProperty("webdriver.chrome.driver",
                "C:\\SWDTOOLS\\Selenium\\Selenium-ChromeDriver v32_2.3 (to support chrome v28-31)\\chromedriver.exe");
            Framework.driver = new ChromeDriver();

            if (Channel.equalsIgnoreCase("Agent_Channel")) {
                Framework.driver.get(getConfigData("Agent_URL"));
            } else if (Channel.equalsIgnoreCase("Customer_Channel")) {
                Windows_Login_1 wl = new Windows_Login_1();
                Windows_Login_2 tt1 = new Windows_Login_2(wl, "FirstLogin");
                tt1.start();
                Framework.driver.get(getConfigData("Customer_URL"));
            }
            Framework.driver.manage().window().maximize();
            Framework.driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        }

        if (browser.equalsIgnoreCase("ie")) {
            System
                .setProperty("webdriver.ie.driver",
                    "C:\\SWDTOOLS\\Selenium\\Selenium-Internet Explorer Driver Server v2.35.3 (for 32 bit Windows IE)\\IEDriverServer.exe");
            Framework.driver = new InternetExplorerDriver();
            atu.testng.reports.ATUReports.setWebDriver(Framework.driver);

            if (Channel.equalsIgnoreCase("Agent_Channel")) {
                if (Library.Environment.equalsIgnoreCase("SIT")) {
                    if (Library.url.equalsIgnoreCase("hk341")) {
                        Framework.driver.get(getConfigData("SIT_Agent_URL1_hk341"));

                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("SIT_Agent_UserID_hk341"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("SIT_Agent_Password_hk341"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("SIT_Agent_URL2_hk341"));
                    }
                    if (Library.url.equalsIgnoreCase("eu461")) {
                        Framework.driver.get(getConfigData("SIT_Agent_URL1_eu461"));

                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("SIT_Agent_UserID_eu461"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("SIT_Agent_Password_eu461"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("SIT_Agent_URL2_eu461"));
                    }
                    if (Library.url.equalsIgnoreCase("eu425")) {
                        Framework.driver.get(getConfigData("SIT_Agent_URL1_eu425"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("SIT_Agent_UserID_eu425"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("SIT_Agent_Password_eu425"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("SIT_Agent_URL2_eu425"));
                    }
                } else if (Library.Environment.equalsIgnoreCase("DIT")) {
                    if (Library.url.equalsIgnoreCase("eu463")) {
                        Framework.driver.get(getConfigData("DIT_Agent_URL1_eu463"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "user_id"))).sendKeys(
                            getConfigData("DIT_Agent_UserID_eu463"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "password"))).sendKeys(
                            getConfigData("DIT_Agent_Password_eu463"));
                        Framework.driver.findElement(By.xpath(getobjectdata("Login_Page", "login_button"))).click();
                        Framework.driver.get(getConfigData("DIT_Agent_URL2_eu463"));
                    }
                } else if (Library.Environment.equalsIgnoreCase("UAT")) {
                    if (Library.url.equalsIgnoreCase("hk342")) {
                        Framework.driver.get(getConfigData("UAT_Agent_URL1_hk342"));
                        Framework.driver.findElement(By.xpath("//a[text()='Custom Home Logon']")).click();
                        Framework.driver.findElement(By.xpath("//input[contains(@id,'customLogin:userId')]")).sendKeys(
                            getConfigData("UAT_Agent_UserID_hk342"));
                        Thread.sleep(1000);
                        Framework.driver.findElement(By.xpath("//input[contains(@id,'customLogin:password')]")).sendKeys(
                            getConfigData("UAT_Agent_Password_hk342"));
                        Framework.driver.findElement(By.xpath("//input[@value='Login']")).click();
                        Framework.driver.get(getConfigData("UAT_Agent_URL2_hk342"));
                    }
                }
            } else if (Channel.equalsIgnoreCase("Customer_Channel")) {

                Windows_Login_1 wl = new Windows_Login_1();
                Windows_Login_2 tt1 = new Windows_Login_2(wl, "FirstLogin");
                if (Library.Environment.equalsIgnoreCase("SIT")) {
                    if (Library.url.equalsIgnoreCase("hk74")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("SIT_Customer_URL_hk74"));
                    }
                    if (Library.url.equalsIgnoreCase("hk375")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("SIT_Customer_URL_hk375"));
                    }
                } else if (Library.Environment.equalsIgnoreCase("DIT")) {
                    if (Library.url.equalsIgnoreCase("eu450")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("DIT_Customer_URL_eu450"));
                        Library.url = getConfigData("DIT_Customer_URL_eu450");
                    }
                } else if (Library.Environment.equalsIgnoreCase("UAT")) {
                    if (Library.url.equalsIgnoreCase("hk72")) {
                        tt1.start();
                        Framework.driver.get(getConfigData("UAT_Customer_URL_hk72"));
                        Library.url = getConfigData("UAT_Customer_URL_hk72");
                    }
                }
            }

            try {
                Framework.driver.get("javascript:document.getElementById('overridelink').click();");
                Thread.sleep(2000);
            } catch (Exception e) {
                System.out.println("No Override link present");
            }
            boolean flag = true;
            while (flag) {
                try {
                    Alert alert = Framework.driver.switchTo().alert();
                    alert.accept();
                    // System.out.println("Alert Present");

                } catch (Exception ex) {
                    // System.out.println("No Alret Present");
                    flag = false;
                }
            }
            Framework.driver.manage().window().maximize();
            Framework.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        }
    }

    public static void Select_Loan() throws Exception {
        // String fee_free = gettestdata("Fee_Free");

        int no_of_loan = Integer.parseInt(gettestdata("Number_of_Loans"));

        int a = 100000 / no_of_loan;
        String amount_per_loan = Integer.toString(a);
        int i = 1;
        Select select_mortgage_type;
        while (i <= no_of_loan) {
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseHOL"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "filter_results"))).click();
                select_mortgage_type = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "HOL_type"))));

                String loan_type = "Loan_Type" + i;

                select_mortgage_type.selectByVisibleText(gettestdata(loan_type));

                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "update_HOL_result"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseHOL"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Select_random_Rates"))).click();
                if (i < no_of_loan) {

                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Selected_HOL"))).click();

                    List<WebElement> Edit_Rate = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "Edit_HOL_Rate")));
                    Edit_Rate.get(i - 1).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_HOL_Amount_Button"))).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_HOL_Amount_Field"))).clear();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_HOL_Amount_Field"))).sendKeys(
                        amount_per_loan);
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "save_HOL_Amount_change"))).click();

                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "choose_another_HOL"))).click();

                }
                i++;
            }

            else {

                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseMortgage"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "filter_results"))).click();
                select_mortgage_type = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "mortgage_type"))));

                String loan_type = "Loan_Type" + i;

                select_mortgage_type.selectByVisibleText(gettestdata(loan_type));

                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "update_result"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseMortgage"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Select_random_Rates"))).click();
                if (i < no_of_loan) {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Selected_Rates"))).click();

                    List<WebElement> Edit_Rate = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "Edit_Rate")));
                    Edit_Rate.get(i - 1).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Amount_Button"))).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Amount_Field"))).clear();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Amount_Field"))).sendKeys(amount_per_loan);
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "save_Amount_change"))).click();

                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "choose_another_mortgage"))).click();
                }
                i++;
            }
        }
    }

    public static void select_dropdown(final Select dropdown, final String value) {
        // System.out.println("dropdown value: " +
        // dropdown.getFirstSelectedOption().getText().toString());
        try {
            if ((dropdown.getFirstSelectedOption().getText()).equalsIgnoreCase("Please select")
                || dropdown.getFirstSelectedOption().getText().equalsIgnoreCase("Please choose")) {
                dropdown.selectByVisibleText(value);

            }
        } catch (Exception E) {
        }
    }

    public static void selectbyIndex_dropdown(final Select dropdown, final int value) {
        /*
         * System.out.println("Inside selct Index");
         * System.out.println(dropdown.getFirstSelectedOption().getText());
         */
        try {
            if ((dropdown.getFirstSelectedOption().getText()).equalsIgnoreCase("Please select")
                || dropdown.getFirstSelectedOption().getText().equalsIgnoreCase("Please choose")) {
                // System.out.println("Inside IF");
                dropdown.selectByIndex(value);
            } else {
                System.out.println("Inside Else");
                System.out.println(dropdown.getFirstSelectedOption().getText());
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
    }
    public static boolean prefilled_flag = true;

    public static void enter_data(final WebElement field, final String value) {
        // System.out.println("Field value: " + field.getAttribute("value"));
        Library.prefilled_flag = true;
        try {
            if (field.getAttribute("value").equals("")) {
                // field.clear();
                field.sendKeys(value);
                Library.prefilled_flag = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
