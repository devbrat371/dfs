/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2015. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package framework;

/**
 * <p>
 * <b> TODO : This Class is used to handle windows Authentication. </b>
 * </p>
 */
public class Windows_Login_2 extends Thread {
    private Windows_Login_1 wl;

    public Windows_Login_2(final Windows_Login_1 wl, final String name) {
        super(name); // Save thread's name
        this.wl = wl;
    }


    public void run() {
        String UserID = null;
        String Password = null;
        try {
            if (Library.Environment.equalsIgnoreCase("SIT")) {
                if (Library.url.equalsIgnoreCase("hk74")) {
                    UserID = Framework.getConfigData("SIT_Customer_UserID_hk74");
                    Password = Framework.getConfigData("SIT_Customer_Password_hk74");
                }
                if (Library.url.equalsIgnoreCase("hk375")) {
                    UserID = Framework.getConfigData("SIT_Customer_UserID_hk375");
                    Password = Framework.getConfigData("SIT_Customer_Password_hk375");
                }
                if (Library.url.equalsIgnoreCase("eu474")) {
                    UserID = Framework.getConfigData("SIT_Customer_UserID_eu474");
                    Password = Framework.getConfigData("SIT_Customer_Password_eu474");
                }
            }
            if (Library.Environment.equalsIgnoreCase("DIT")) {
                if (Library.url.equalsIgnoreCase("eu450")) {
                    UserID = Framework.getConfigData("DIT_Customer_UserID_eu450");
                    Password = Framework.getConfigData("DIT_Customer_Password_eu450");
                }
            }
            if (Library.Environment.equalsIgnoreCase("UAT")) {
                if (Library.url.equalsIgnoreCase("hk72")) {
                    UserID = Framework.getConfigData("UAT_Customer_UserID_hk72");
                    Password = Framework.getConfigData("UAT_Customer_Password_hk72");
                }
            }
            if (getName().equals("FirstLogin")) {

                this.wl.login(UserID, Password);
            } else {
                this.wl.login(UserID, Password);
            }

        } catch (Exception ex) {
            System.out.println("Error in Login Thread: " + ex.getMessage());
        }
    }

}
