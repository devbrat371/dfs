/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package End_to_End_Flow;


import java.text.DecimalFormat;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Common_Library.Common_Functions;
import Mortgage_Data_Creation.MQ_Test_Harness;
import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Agent_Advised_Journey extends Framework {

    @Test
    public static void Agent_Advised_Flow() throws Exception {

        double startTime = System.currentTimeMillis();
        Library.startSelenium("Agent_Channel");
        String Env = Library.Environment;
        String app_id;
        Boolean flag = false;
        String Journey_Till;

        Journey_Till = gettestdata("Journey_Till");
        Execution: try {
            Framework.log_report("PASS", "Data Staging Journey Started on: " + Library.url, "No");
            if (gettestdata("Referrence_App_ID").equalsIgnoreCase("NA")) {
                Common_Functions.search_Customer();
                Common_Functions.Add_Customer();

                if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("Agent_Gateway_Page", "Add_Applicant"))).click();
                    Common_Functions.search_Customer();

                    Common_Functions.Add_Customer();
                }
            } else {
                // Application Search Page
                Framework.log_report("PASS", "Journey Started on: " + Library.url, "No");
                Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "search_App"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "App_ref"))).sendKeys(
                    gettestdata("Referrence_App_ID"));
                Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "search"))).click();
            }
            // Agent Gateway
            Framework.driver.findElement(By.xpath(getobjectdata("Agent_Gateway_Page", "DIP_Button"))).click();

            // Present at Interview

            Framework.driver.findElement(By.xpath(getobjectdata("Present_at_Interview", "presentradiobutton_Yes"))).click();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Present_at_Interview", "Joint_applicant_access"))).click();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("Present_at_Interview", "Save_Button"))).click();

            // Before you Start
            Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "Triage_Response_1"))).click();
            List<WebElement> continue_button = Framework.driver.findElements(By.xpath(getobjectdata("Before_Your_Start_Page",
                "Continue_App")));
            Thread.sleep(1000);
            for (int i = 0; i < continue_button.size(); i++) {

                if (continue_button.get(i).isDisplayed() && continue_button.get(i).isEnabled()) {
                    continue_button.get(i).click();
                    i = continue_button.size();
                }
            }
            // What would you like to do
            if (gettestdata("Property_Type").equalsIgnoreCase("Main Home")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "property_option1"))).click();

                Select selectLooking = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "What_would_you_like_to_do_Page", "buyertype_mainhome"))));
                selectLooking.selectByVisibleText(gettestdata("Buyer_Type"));

                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow extra - for EXISTING customers")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("What_would_you_like_to_do_Page", "debtConsolidationMainHome_Yes"))).click();
                } else {
                    Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "Right_to_buy_yes")))
                        .click();
                }
            }

            else if (gettestdata("Property_Type").equalsIgnoreCase("Second Home")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "property_option2"))).click();

                Select selectLooking = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "What_would_you_like_to_do_Page", "buyertype_secondhome"))));
                selectLooking.selectByVisibleText(gettestdata("Buyer_Type"));

                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow extra - for EXISTING customers")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("What_would_you_like_to_do_Page", "debtConsolidationSecondHome_Yes"))).click();
                }
            }

            else if (gettestdata("Property_Type").equalsIgnoreCase("BTL")) {
                Display_Popup("OOPS!!!", "You Cannot Select BTL option for Advised Flow");
                Framework.driver.quit();
            }
            Thread.sleep(5000);
            Framework.log_report("PASS", "Service Type Page", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "submit"))).click();
            String parent = Framework.driver.getWindowHandle();

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "advice_flow_button"))).click();
            Thread.sleep(5000);


            Framework.driver.switchTo().window(parent);


            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continuewithadvice_button")))
                .click();
            List<WebElement> CIN = Framework.driver.findElements(By.className("control-bar"));
            for (WebElement element : CIN) {
                System.out.println(element.getText());
            }

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continue_button"))).click();

            String username = Framework.driver.findElement(
                By.xpath(getobjectdata("What_would_you_like_to_do_Page", "UserID_Agent"))).getText();
            username = username.split("Your username is: ")[1];
            System.out.println("UserName: " + username);
            update_UserID(Mortgage_Data_Creation.E2E_Test.rowCount, username);

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continue2_button"))).click();

            // Application ID Generation
            if (Env.equalsIgnoreCase("UAT")) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_save_and_exit")))
                        .click();
                } catch (Exception E) {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_save_and_exit")))
                        .click();
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_confirm_exit"))).click();
                String str1 = Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Agent_app_id"))).getText();

                app_id = str1.split("Application reference number ")[1];
                Framework.log_report("PASS", "Application ID Generated: " + app_id, "Yes");
                System.out.println("****App id: " + app_id);
                update_AppID(Mortgage_Data_Creation.E2E_Test.rowCount, app_id);


                Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Save_and_Continue"))).click();

            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "save_and_exit"))).click();
                String str1 = Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Agent_app_id"))).getText();
                // System.out.println(str1);
                app_id = str1.split("Application reference number ")[1];
                // String app_id = str1.split(" to any documents")[0];
                System.out.println("****App id: " + app_id);
                Framework.log_report("PASS", "Application ID Generated: " + app_id, "Yes");
                update_AppID(Mortgage_Data_Creation.E2E_Test.rowCount, app_id);

                Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Save_and_Continue"))).click();

            }

            // GAD1 Personal Details
            Common_Functions.Fill_NTB_GAD1_PersonalDetails();

            // GAD personal details coapplicant
            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD1_PersonalDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD1 Personal Details")) {
                flag = true;
                break Execution;
            }
            // GAD 1 Financial details
            Common_Functions.Fill_NTB_GAD1_FinancialDetails();

            // GAD 1 Financial details coapplicant

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD1_FinancialDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD1 Financial Details")) {
                flag = true;
                break Execution;
            }
            // GAD1 Property Details page

            Select selectPropertyLocated = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                "GAD1_Property_Details_Page", "Property_Region"))));
            selectPropertyLocated.selectByVisibleText("London");

            Select selectProertyType = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Type_of_Property"))));
            selectProertyType.selectByVisibleText("Detached house");


            Select selectPropertyOld = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "How_old_property"))));
            selectPropertyOld.selectByVisibleText("Up to 8 years");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Property_occupied"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_outgoing")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_contractual")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Borrowing_required"))).sendKeys(
                "100000");

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_radiobutton"))).click();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_propertyvalue"))).sendKeys(
                "3000000");

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Select Purpose_of_loan = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Purpose_of_loan"))));
                Purpose_of_loan.selectByVisibleText("Home improvement only");
            }

            Select selectPreferPay = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Repayment_dropdown"))));
            selectPreferPay.selectByVisibleText(gettestdata("Repayment_Type"));


            Select selectMortgageYY = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Mortgage_term_years"))));
            selectMortgageYY.selectByVisibleText("20");

            Select selectMortgageMM = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Mortgage_term_months"))));
            selectMortgageMM.selectByVisibleText("6");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "other_Currency_Income_No"))).click();
            Framework.log_report("PASS", "GAD1 Property Details Complete", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue1_button"))).click();
            if (Journey_Till.equalsIgnoreCase("GAD1 Property Details")) {
                flag = true;
                break Execution;
            }

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue2_button"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Confirm_checkbox"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue3_button"))).click();
            Framework.log_report("PASS", "DIP Complete", "Yes");
            if (Journey_Till.equalsIgnoreCase("DIP")) {
                flag = true;
                break Execution;
            }

            List<WebElement> LTV = Framework.driver.findElements(By.className("csCol-3"));
            for (WebElement element : LTV) {
                System.out.println(element.getText());
            }
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue4_button"))).click();


            // GAD 2 Personal Details
            Common_Functions.Fill_NTB_GAD2_PersonalDetails();

            // GAD2 Personal Details for Coapplicant
            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD2_PersonalDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD2 Personal Details")) {
                flag = true;
                break Execution;
            }

            // GAD2 Financial Details Page
            Common_Functions.Fill_NTB_GAD2_FinancialDetails();
            // GAD2 Financial Details Page for coapplicant

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                try {
                    Select selectEmployment1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Emp_Status"))));
                    Library.select_dropdown(selectEmployment1, "Employed - full time");
                } catch (Exception E) {
                }
                Common_Functions.Fill_NTB_GAD2_FinancialDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD2 Financial Details")) {
                flag = true;
                break Execution;
            }

            // GAD 2 Property details page

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropAddrText"))).sendKeys("S1 3GG");

            boolean add_flag = true;
            while (add_flag) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "FindAddr"))).click();
                    Select selectPropertyAddress = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                        "PropAddrList"))));
                    selectPropertyAddress.selectByIndex(1);
                    add_flag = false;
                } catch (Exception e) {
                    add_flag = true;
                }
            }
            Select selectTenure = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Tenure"))));
            selectTenure.selectByVisibleText("Freehold");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropConv"))).click();

            Select selectBeddRom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "NumofBedroom"))));
            selectBeddRom.selectByVisibleText("2");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropListed"))).click();

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Transfer my mortgage to HSBC")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "other_loan_amount"))).sendKeys("0");
            }
            Select selectPropertyConstructed = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                "PropConstr_Agent"))));
            selectPropertyConstructed.selectByVisibleText("Timber Frame");
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "EstPrice"))).sendKeys("3000000");
                Select selectDepositFrom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                    "MethodDeposit"))));
                selectDepositFrom.selectByVisibleText("Savings");

            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")
                && gettestdata("Property_Type").equalsIgnoreCase("Second Home")) {
                Select selectScheme = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Scheme"))));
                selectScheme.selectByVisibleText("No");
            }
            Framework.log_report("PASS", "GAD2 Property Details Complete", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continue"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continuenav"))).click();


            if (Journey_Till.equalsIgnoreCase("GAD2 Property Details")) {
                flag = true;
                break Execution;
            }

            // ACM

            Framework.driver.findElement(By.xpath(getobjectdata("ACM", "Launch_Quotes"))).click();

            if (!(gettestdata("Referrence_App_ID").equalsIgnoreCase("NA"))) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "existing_prop"))).click();
                } catch (Exception e) {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Sellingproperty_checkbox"))).click();
                }
                Framework.log_report("PASS", "Existing Property Page", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "existing_prop_Continue"))).click();

            } else {
                if (gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "EP_Continue"))).click();
                }

                else if (gettestdata("Buyer_Type").equalsIgnoreCase("Transfer my mortgage to HSBC")
                    && gettestdata("Property_Type").equalsIgnoreCase("Second Home")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "EP_Continue"))).click();
                }
            }
            // Quotes
            Select selectscheme = new Select(
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Prop_purchase_scheme"))));
            selectscheme.selectByVisibleText("No");
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Transfer my mortgage to HSBC")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "owned_more_than_6months_yes"))).click();

            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                // Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                // "Purchase_Price"))).clear();
                // Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                // "Purchase_Price"))).sendKeys("3000000");
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "DepositAmt"))).sendKeys("2900000");
                Select selectdepositsource = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "Deposit_Source"))));
                selectdepositsource.selectByVisibleText("Savings");
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                Select selectMortgagType = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "Borrowmore_ProductRange"))));
                selectMortgagType.selectByVisibleText("Fixed");
            } else {
                Select selectMortgagType = new Select(Framework.driver.findElement(By
                    .xpath(getobjectdata("Quotes", "ProductRange"))));
                selectMortgagType.selectByVisibleText("Fixed");
            }
            Framework.log_report("PASS", "MPD Page", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "SARSaveContinue"))).click();
            List<WebElement> Continue_creating_mortgage = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                "Continue_creating_mortgage")));
            for (int i = 0; i < Continue_creating_mortgage.size(); i++) {
                if (Continue_creating_mortgage.get(i).isDisplayed() && Continue_creating_mortgage.get(i).isEnabled()) {
                    Continue_creating_mortgage.get(i).click();
                    i = Continue_creating_mortgage.size();
                }
            }

            Library.Select_Loan();

            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Continue"))).click();

            try {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Incentive"))).click();
            } catch (Exception e) {
            }

            List<WebElement> LoanCapital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanCapital")));
            List<WebElement> LoanRecalc = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanRecalc")));
            for (int i = 0; i < LoanCapital.size(); i++) {
                LoanCapital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanCapital")));
                Select selectQuotes = new Select(LoanCapital.get(i));
                selectQuotes.selectByVisibleText("Pay fee up-front");
                LoanRecalc = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanRecalc")));
                LoanRecalc.get(i).click();

            }
            if (gettestdata("Repayment_Type").equalsIgnoreCase("Interest only")) {
                List<WebElement> Adhoc_capital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "Adhoc_capital")));
                for (int i = 0; i < Adhoc_capital.size(); i++) {
                    Adhoc_capital.get(i).click();
                }
                try {
                    if (Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "foreignCurrencyRadio_no"))).isDisplayed()
                        && Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "foreignCurrencyRadio_no"))).isEnabled()) {
                        List<WebElement> foreigncurrency_radio = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                            "foreignCurrencyRadio_no")));
                        for (int i = 0; i < foreigncurrency_radio.size(); i++) {
                            foreigncurrency_radio.get(i).click();
                        }
                    }
                } catch (Exception E) {
                }
            }
            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "SaveContinue"))).click();

            if (Journey_Till.equalsIgnoreCase("Quote Summary")) {
                flag = true;
                break Execution;
            }
            Framework.log_report("PASS", "Quotes Complete", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Apply"))).click();
            List<WebElement> Countinue_without_Booking_Rates = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                "Countinue_without_Booking_Rates")));
            for (int i = 0; i < Countinue_without_Booking_Rates.size(); i++) {
                if (Countinue_without_Booking_Rates.get(i).isDisplayed() && Countinue_without_Booking_Rates.get(i).isEnabled()) {
                    Countinue_without_Booking_Rates.get(i).click();
                    i = Countinue_without_Booking_Rates.size();
                }
            }

            // ACM
            Framework.driver.findElement(By.xpath(getobjectdata("ACM", "ReadyforSol"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("ACM", "RecommGen"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("ACM", "RecommAcc"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("ACM", "FCD"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("ACM", "Confirm"))).click();


            Framework.driver.findElement(By.xpath(getobjectdata("ACM", "FCDCRA"))).click();

            if (Journey_Till.equalsIgnoreCase("FCD")) {
                flag = true;
                break Execution;
            }

            // Valuation Page
            Common_Functions.Complete_Valuation();

            if (Journey_Till.equalsIgnoreCase("Valuation")) {
                flag = true;
                break Execution;
            }

            // Conveyancing Details Page
            Common_Functions.Complete_ConveyancingDetails();

            if (Journey_Till.equalsIgnoreCase("Conveyancing Details")) {
                flag = true;
                break Execution;
            }

            // DD page
            Common_Functions.Complete_DD();

            if (Journey_Till.equalsIgnoreCase("DD")) {
                flag = true;
                break Execution;
            }

            if (Env.equalsIgnoreCase("UAT")) {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
            }

            // Application Maintenance
            Common_Functions.Complete_Application_Maintenance();

            // Document and Correspondence
            Common_Functions.Complete_Document_and_Correspondence();

            // Pay Fees
            Common_Functions.Pay_Fees();

            boolean condition = false;
            if (Journey_Till.equalsIgnoreCase("Payments")) {
                flag = true;
                break Execution;
            }

            // MQTESTHARNESS
            try {
                condition = Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "PropVal"))).isDisplayed();
                System.out.println(condition);
            } catch (Exception E) {
            }
            if (condition) {
                String Testharness_result = MQ_Test_Harness.MQTestHarness(app_id);
                if (Testharness_result.equalsIgnoreCase("return code=0")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "PropVal"))).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "ValConfirm"))).click();
                } else {
                    System.out.println("***MQTESTHARNESS Return code not equal to 0");
                    // Framework.driver.quit();
                }
            }
            boolean status_condition = false;

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Joint_Applicant_Confirmation();
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer"))).click();
                try {
                    Thread.sleep(1000);
                    if (Env.equalsIgnoreCase("UAT")) {

                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                    } else {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    }
                } catch (Exception E) {
                }
                String Status = Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "what_done_so_far"))).getText();
                status_condition = Status.toLowerCase().contains("mortgage offer generated")
                    || Status.toLowerCase().contains("mortgage offer created");
            } else {
                if (condition) {
                    Thread.sleep(1000);
                    try {
                        if (Env.equalsIgnoreCase("UAT")) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                        } else {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                        }
                    } catch (Exception E) {
                        if (Env.equalsIgnoreCase("UAT")) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                        } else {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                        }
                    }
                    try {
                        if (Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer")))
                            .isDisplayed()
                            && Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer")))
                                .isEnabled()) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer"))).click();
                            if (Env.equalsIgnoreCase("UAT")) {

                                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                            } else {
                                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                            }
                        }
                    } catch (Exception E) {
                    }
                    String Status = Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "what_done_so_far"))).getText();
                    System.out.println(Status.toLowerCase());
                    status_condition = Status.toLowerCase().contains("mortgage offer generated")
                        || Status.toLowerCase().contains("mortgage offer created");
                    System.out.println("Execution Status: " + status_condition);
                } else {
                    Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer"))).click();
                    try {
                        if (Env.equalsIgnoreCase("UAT")) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                        } else {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                        }
                    } catch (Exception E) {
                    }
                    String Status = Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "what_done_so_far"))).getText();
                    System.out.println(Status.toLowerCase());
                    status_condition = Status.toLowerCase().contains("mortgage offer generated")
                        || Status.toLowerCase().contains("mortgage offer created");
                    System.out.println("Execution Status: " + status_condition);
                }
            }
            if (status_condition) {
                Framework.log_report("PASS", "Offer Generation Complete", "No");
                Framework.log_report("PASS", "Data Staging Complete", "Yes");
                System.out.println("Executon Completed");
                update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");
                double endTime = System.currentTimeMillis();
                double totalTime = endTime - startTime;
                totalTime = totalTime / 60000;
                totalTime = Double.parseDouble(new DecimalFormat("##.##").format(totalTime));
                System.out.println("Total Execution Time: " + totalTime + " Minutes");
                // Display_Popup("Thank You!!!", "Execution Complete");
            } else {
                // takeScreenshot("Agent_Error_Page");
                // Display_Popup("Error!!!", "Execution Failed");
                update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "FAIL");
            }
        } catch (Exception E) {
            // takeScreenshot("Agent_Error_Page");
            E.printStackTrace();
            // Display_Popup("Error!!!", "Execution Failed");
            Framework.log_report("FAIL", "Execution Failed", "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "FAIL");
        }
        if (flag) {
            System.out.println("Execution done till:" + Journey_Till);
            Framework.log_report("PASS", "Journey Complete till " + Journey_Till, "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");
        }
        // Framework.driver.quit();
    }
}