/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package End_to_End_Flow;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Common_Library.Common_Functions;
import Mortgage_Data_Creation.MQ_Test_Harness;
import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Existing_Agent_Non_Advised_Journey extends Framework {
    @Test
    public static void Existing_Agent_Non_Advised_Flow() throws Exception {


        Library.startSelenium("Agent_Channel");
        String Env = Library.Environment;
        String app_id;
        Boolean flag = false;
        String Journey_Till;

        Journey_Till = gettestdata("Journey_Till");
        Execution: try {
            // Application Search Page
            Framework.log_report("PASS", "Journey Started on: " + Library.url, "No");
            Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "search_App"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "App_ref"))).sendKeys(
                gettestdata("Referrence_App_ID"));
            Framework.driver.findElement(By.xpath(getobjectdata("Customer_Search_Page", "search"))).click();
            // Agent Gateway
            Framework.driver.findElement(By.xpath(getobjectdata("Agent_Gateway_Page", "DIP_Button"))).click();

            // Present at Interview

            Framework.driver.findElement(By.xpath(getobjectdata("Present_at_Interview", "presentradiobutton_Yes"))).click();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Present_at_Interview", "Joint_applicant_access"))).click();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("Present_at_Interview", "Save_Button"))).click();

            // Before you Start
            Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "Triage_Response_1"))).click();
            List<WebElement> continue_button = Framework.driver.findElements(By.xpath(getobjectdata("Before_Your_Start_Page",
                "Continue_App")));
            Thread.sleep(1000);
            for (int i = 0; i < continue_button.size(); i++) {

                if (continue_button.get(i).isDisplayed() && continue_button.get(i).isEnabled()) {
                    continue_button.get(i).click();
                    i = continue_button.size();
                }
            }
            // Manage Flow
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "manage_flow"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "manage_flow_conf"))).click();

            // What would you like to do

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "BTL"))).click();

            Framework.driver.findElement(
                By.xpath(getobjectdata("What_would_you_like_to_do_Page", "way_to_cover_mortgage_transfer_manageflow"))).click();
            Framework.driver.findElement(
                By.xpath(getobjectdata("What_would_you_like_to_do_Page", "intend_to_occupy_property_transfer_manageflow"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "own_other_BTL_No_manageflow")))
                .click();
            Framework.driver.findElement(
                By.xpath(getobjectdata("What_would_you_like_to_do_Page", "inheritedInLastFiveYrs_manageflow"))).click();

            if (gettestdata("Let_out_for_business").equalsIgnoreCase("No")) {
                Framework.driver.findElement(
                    By.xpath(getobjectdata("What_would_you_like_to_do_Page", "Let_out_for_business_No_manageflow"))).click();
            } else {
                Framework.driver.findElement(
                    By.xpath(getobjectdata("What_would_you_like_to_do_Page", "Let_out_for_business_Yes_manageflow"))).click();
            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "borrow_more_BTL"))).click();
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "term_change_BTL"))).click();

            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Change Owner")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "change_owner_BTL"))).click();
            }

            Thread.sleep(5000);
            Framework.log_report("PASS", "Service Type Page", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "submit"))).click();

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Framework.driver
                    .findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "borrowmore_debtconsole_No"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "shareowner_no"))).click();
            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Change Owner")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "change_details_both")))
                    .click();
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "name_change_no"))).click();

            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Change Owner")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continue_existing")))
                    .click();
            }
            String parent = Framework.driver.getWindowHandle();

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "NonAdvice_flow_button")))
                .click();
            Thread.sleep(5000);

            Framework.driver.switchTo().window(parent);


            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continuewithNonadvice_button")))
                .click();
            List<WebElement> CIN = Framework.driver.findElements(By.className("control-bar"));
            for (WebElement element : CIN) {
                System.out.println(element.getText());
            }

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continue_button"))).click();

            String username = Framework.driver.findElement(
                By.xpath(getobjectdata("What_would_you_like_to_do_Page", "UserID_Agent"))).getText();
            username = username.split("Your username is: ")[1];
            System.out.println("UserName: " + username);
            update_UserID(Mortgage_Data_Creation.E2E_Test.rowCount, username);

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continue2_button"))).click();
            // Application ID Generation
            if (Env.equalsIgnoreCase("UAT")) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_save_and_exit")))
                        .click();
                } catch (Exception E) {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_save_and_exit")))
                        .click();
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_confirm_exit"))).click();
                String str1 = Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Agent_app_id"))).getText();
                // System.out.println(str1);
                app_id = str1.split("Application reference number ")[1];
                // String app_id = str1.split(" to any documents")[0];
                System.out.println("****App id: " + app_id);
                update_AppID(Mortgage_Data_Creation.E2E_Test.rowCount, app_id);
                Framework.log_report("PASS", "Application ID Generated: " + app_id, "Yes");

                Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Save_and_Continue"))).click();

            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "save_and_exit"))).click();
                String str1 = Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Agent_app_id"))).getText();
                // System.out.println(str1);
                app_id = str1.split("Application reference number ")[1];
                // String app_id = str1.split(" to any documents")[0];
                System.out.println("****App id: " + app_id);
                Framework.log_report("PASS", "Application ID Generated: " + app_id, "Yes");
                update_AppID(Mortgage_Data_Creation.E2E_Test.rowCount, app_id);

                Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Save_and_Continue"))).click();

            }

            // GAD1 Personal Details
            Thread.sleep(3000);
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Select selectcountryresidence = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Country"))));
                try {
                    Library.select_dropdown(selectcountryresidence, "United Kingdom Of Great Britain And Northern Ireland");

                } catch (Exception e) {
                    Library.select_dropdown(selectcountryresidence, "United Kingdom");

                }

                Select selectnationality = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Nationality"))));
                try {
                    Library.select_dropdown(selectnationality, "United Kingdom Of Great Britain And Northern Ireland");

                } catch (Exception e) {
                    Library.select_dropdown(selectnationality, "United Kingdom");

                }
                Thread.sleep(2000);
                /*
                 * selectnationality = new
                 * Select(Framework.driver.findElement(By
                 * .xpath(getobjectdata("GAD1_Personal_Details_Page",
                 * "Nationality"))));
                 */
                /*
                 * if (!(selectnationality.getFirstSelectedOption().getText()
                 * .equalsIgnoreCase
                 * ("United Kingdom Of Great Britain And Northern Ireland"))) {
                 * Framework.driver.findElement(By.xpath(getobjectdata(
                 * "GAD1_Personal_Details_Page", "rightToAbode_no"))).click();
                 * }
                 */

                Select selectAddressco1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "correnspodence_dropdown"))));
                Library.selectbyIndex_dropdown(selectAddressco1, 1);

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "issue_doc_via_other_option")))
                    .click();
                Select selectReminderSent = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Send_Reminder"))));
                Library.select_dropdown(selectReminderSent, "By post");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Select_marketing_format")))
                    .click();

                Framework.driver
                    .findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Send_Reminder_other_format_no"))).click();
                Framework.log_report("PASS", "GAD1 Personal Details Complete", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Continue"))).click();

                if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                    Select selectcountryresidence1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Country"))));
                    try {
                        Library.select_dropdown(selectcountryresidence1, "United Kingdom Of Great Britain And Northern Ireland");

                    } catch (Exception e) {
                        Library.select_dropdown(selectcountryresidence1, "United Kingdom");

                    }


                    Select selectnationality1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Nationality"))));

                    try {
                        Library.select_dropdown(selectnationality1, "United Kingdom Of Great Britain And Northern Ireland");

                    } catch (Exception e) {
                        Library.select_dropdown(selectnationality1, "United Kingdom");

                    }
                    /*
                     * if
                     * (!(selectnationality1.getFirstSelectedOption().getText
                     * ().equalsIgnoreCase("United Kingdom"))) {
                     * Framework.driver.findElement(By.xpath(getobjectdata(
                     * "GAD1_Personal_Details_Page", "rightToAbode_no")))
                     * .click(); }
                     */

                    Select selectAddressco11 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "correnspodence_dropdown"))));
                    Library.selectbyIndex_dropdown(selectAddressco11, 1);

                    Framework.driver.findElement(
                        By.xpath(getobjectdata("GAD1_Personal_Details_Page", "issue_doc_via_other_option_coapp"))).click();
                    Select selectReminderSent1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Send_Reminder"))));
                    Library.select_dropdown(selectReminderSent1, "By post");
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Send_Reminder_other_format_no_coapp"))).click();

                    Framework.log_report("PASS", "GAD1 Personal Details coapplicant Complete", "Yes");
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Continue"))).click();

                }

                // Other Currency
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "other_Currency_Income_No")))
                        .click();

                    Framework.driver.findElement(By.xpath("//input[contains(@id,'continue-button')]")).click();

                } catch (Exception e) {
                }

            } else {
                Select selectcurrentLiving = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Residential_Status"))));
                selectcurrentLiving.selectByVisibleText("Live in a property I own");

                Select selectStatus = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                    "Marital_dropdown"))));
                Library.select_dropdown(selectStatus, "Single");

                Select selectDependent = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "No_of_dependent"))));
                Library.select_dropdown(selectDependent, "0");

                Select selectcountryresidence = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Country"))));
                try {
                    Library.select_dropdown(selectcountryresidence, "United Kingdom Of Great Britain And Northern Ireland");

                } catch (Exception e) {
                    Library.select_dropdown(selectcountryresidence, "United Kingdom");

                }


                Select selectnationality1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Nationality"))));

                try {

                    Library.select_dropdown(selectnationality1, "United Kingdom Of Great Britain And Northern Ireland");

                } catch (Exception e) {
                    Library.select_dropdown(selectnationality1, "United Kingdom");

                }

                /*
                 * if (!(selectnationalitye.getFirstSelectedOption().getText().
                 * equalsIgnoreCase("United Kingdom"))) {
                 * Framework.driver.findElement
                 * (By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                 * "rightToAbode_no"))).click(); }
                 */

                /*
                 * Select selectByutoLet = new
                 * Select(Framework.driver.findElement(By.xpath(getobjectdata(
                 * "GAD1_Personal_Details_Page", "Other_resident"))));
                 * Library.select_dropdown(selectByutoLet, "None");
                 */

                WebElement work_phone_int = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                    "Work_Phone_int")));
                Library.enter_data(work_phone_int, "+111");
                WebElement work_phone_std = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                    "Work_Phone_std")));
                Library.enter_data(work_phone_std, "1111111");
                WebElement work_phone_number = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                    "Work_Phone_number")));
                Library.enter_data(work_phone_number, "11111111");
                Select selectAddressco1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "correnspodence_dropdown"))));
                Library.selectbyIndex_dropdown(selectAddressco1, 1);
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "issue_doc_via_other_option")))
                    .click();
                Select selectReminderSent = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Send_Reminder"))));
                Library.select_dropdown(selectReminderSent, "By post");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Select_marketing_format")))
                    .click();

                Framework.driver
                    .findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Send_Reminder_other_format_no"))).click();
                Framework.log_report("PASS", "GAD1 Personal Details Complete", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Continue"))).click();


                // GAD personal details coapplicant
                if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                    Thread.sleep(2000);
                    Select selectcurrentLiving1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Residential_Status"))));
                    selectcurrentLiving1.selectByVisibleText("Live in a property I own");


                    Select selectStatus1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Marital_dropdown"))));
                    Library.select_dropdown(selectStatus1, "Single");

                    Select selectDependent1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "No_of_dependent"))));
                    Library.select_dropdown(selectDependent1, "0");

                    Select selectcountryresidence1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Country"))));
                    try {
                        Library.select_dropdown(selectcountryresidence1, "United Kingdom Of Great Britain And Northern Ireland");

                    } catch (Exception e) {
                        Library.select_dropdown(selectcountryresidence1, "United Kingdom");

                    }

                    Select selectnationality = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Nationality"))));

                    try {
                        Library.select_dropdown(selectnationality, "United Kingdom Of Great Britain And Northern Ireland");

                    } catch (Exception e) {
                        Library.select_dropdown(selectnationality, "United Kingdom");

                    }
                    /*
                     * if
                     * (!(selectnationalitye1.getFirstSelectedOption().getText
                     * ().equalsIgnoreCase("United Kingdom"))) {
                     * Framework.driver.findElement(By.xpath(getobjectdata(
                     * "GAD1_Personal_Details_Page", "rightToAbode_yes")))
                     * .click(); }
                     */

                    /*
                     * Select selectByutoLet1 = new
                     * Select(Framework.driver.findElement
                     * (By.xpath(getobjectdata( "GAD1_Personal_Details_Page",
                     * "Other_resident"))));
                     * Library.select_dropdown(selectByutoLet1, "None");
                     */

                    WebElement work_phone_int1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                        "Work_Phone_int")));
                    Library.enter_data(work_phone_int1, "+111");
                    WebElement work_phone_std1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                        "Work_Phone_std")));
                    Library.enter_data(work_phone_std1, "1111111");
                    WebElement work_phone_number1 = Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Work_Phone_number")));
                    Library.enter_data(work_phone_number1, "11111111");

                    Select selectAddressco1_1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "correnspodence_dropdown"))));
                    Library.selectbyIndex_dropdown(selectAddressco1_1, 1);
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("GAD1_Personal_Details_Page", "issue_doc_via_other_option"))).click();
                    Select selectReminderSent1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Send_Reminder"))));
                    Library.select_dropdown(selectReminderSent1, "By post");

                    Framework.driver.findElement(
                        By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Send_Reminder_other_format_no"))).click();

                    // Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                    // "Select_marketing_format"))).click();
                    Framework.log_report("PASS", "GAD1 Personal Details for co-applicant Complete", "Yes");
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "Continue"))).click();

                }
                if (Journey_Till.equalsIgnoreCase("GAD1 Personal Details")) {
                    flag = true;
                    break Execution;
                }
                // GAD 1 Financial details
                Select selectEmployment = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Financial_Details_Page", "Emp_Status"))));
                Library.select_dropdown(selectEmployment, "Employed - full time");
                try {
                    WebElement grad_year = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Graduation_Year")));
                    Library.enter_data(grad_year, "2000");
                } catch (Exception e) {
                }
                try {
                    Select selectWorkingArea = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Emp_Business"))));
                    Library.select_dropdown(selectWorkingArea, "Computers & Telecommunications");


                    Select selectOccupation = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Occupation_Type"))));
                    Library.select_dropdown(selectOccupation, "Manual - Supervisory");

                    Select selectSepcificOCC = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Specific_occupation"))));
                    Library.select_dropdown(selectSepcificOCC, "Agricultural worker");

                    WebElement jobtitle = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Job_Title")));
                    Library.enter_data(jobtitle, "audsjhidbq");

                    WebElement empstartdate = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Day")));
                    empstartdate.clear();
                    empstartdate.sendKeys("15");

                    WebElement empstartmonth = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Month")));
                    empstartmonth.clear();
                    empstartmonth.sendKeys("05");

                    WebElement empstartyear = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Year")));
                    empstartyear.clear();
                    empstartyear.sendKeys("2000");
                } catch (Exception e) {
                }
                try {
                    Select selectPaidTIME = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Income_Frequency"))));
                    Library.select_dropdown(selectPaidTIME, "Every month");


                    Select selectPaidBY = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Income_Method"))));
                    Library.select_dropdown(selectPaidBY, "Direct to Bank / BACS");
                } catch (Exception e) {
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income"))).clear();

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income")))
                    .sendKeys(gettestdata("Salary"));


                WebElement otherincome = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Other_Income")));
                Library.enter_data(otherincome, "200");

                Select selectBank = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Time_with_Bank_Years"))));
                selectBank.selectByVisibleText("10");

                Select selectBankmm = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Time_with_Bank_Month"))));
                selectBankmm.selectByVisibleText("10");

                Select selectDC = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Number_of_Debit_cards"))));
                Library.select_dropdown(selectDC, "1");

                Select selectCC = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Number_of_Credit_cards"))));
                Library.select_dropdown(selectCC, "1");


                WebElement outstanding = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Outstanding_balance")));
                Library.enter_data(outstanding, "0");
                WebElement monthlyloan = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Total_monthly_loan")));
                Library.enter_data(monthlyloan, "0");
                Framework.log_report("PASS", "GAD1 Financial Details Complete", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Continue"))).click();


                // GAD 1 Financial details coapplicant

                if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                    Select selectEmployment1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Emp_Status"))));
                    Library.select_dropdown(selectEmployment1, "Employed - full time");
                    try {
                        Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "comp_director_no")))
                            .click();
                    } catch (Exception e) {
                    }
                    Select selectWorkingArea1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Emp_Business"))));
                    Library.select_dropdown(selectWorkingArea1, "Computers & Telecommunications");


                    Select selectOccupation1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Occupation_Type"))));
                    Library.select_dropdown(selectOccupation1, "Manual - Supervisory");

                    Select selectSepcificOCC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Specific_occupation"))));
                    Library.select_dropdown(selectSepcificOCC1, "Agricultural worker");
                    WebElement jobtitle1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Job_Title")));
                    Library.enter_data(jobtitle1, "audsjhidbq");

                    WebElement empstartdate1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Day")));
                    // Library.enter_data(empstartdate1, "15");
                    empstartdate1.clear();
                    empstartdate1.sendKeys("15");

                    WebElement empstartmonth1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Month")));
                    // Library.enter_data(empstartmonth1, "05");
                    empstartmonth1.clear();
                    empstartmonth1.sendKeys("05");
                    WebElement empstartyear1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Year")));
                    // Library.enter_data(empstartyear1, "2000");
                    empstartyear1.clear();
                    empstartyear1.sendKeys("2000");
                    try {
                        Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "other_employment_no")))
                            .click();
                    } catch (Exception e) {
                    }
                    Select selectPaidTIME1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Income_Frequency"))));
                    Library.select_dropdown(selectPaidTIME1, "Every month");


                    Select selectPaidBY1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Income_Method"))));
                    Library.select_dropdown(selectPaidBY1, "Direct to Bank / BACS");
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income")))
                        .clear();
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income")))
                        .sendKeys(gettestdata("Salary"));

                    WebElement otherincome1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Other_Income")));
                    Library.enter_data(otherincome1, "200");


                    Select selectBank1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Time_with_Bank_Years"))));
                    selectBank1.selectByVisibleText("10");

                    Select selectBankmm1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Time_with_Bank_Month"))));
                    selectBankmm1.selectByVisibleText("10");

                    Select selectDC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Number_of_Debit_cards"))));
                    Library.select_dropdown(selectDC1, "1");

                    Select selectCC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Number_of_Credit_cards"))));
                    Library.select_dropdown(selectCC1, "1");


                    WebElement outstanding1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Outstanding_balance")));
                    Library.enter_data(outstanding1, "0");
                    WebElement monthlyloan1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Total_monthly_loan")));
                    Library.enter_data(monthlyloan1, "0");
                    Framework.log_report("PASS", "GAD1 Financial Details for co-applicant Complete", "Yes");
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Continue"))).click();


                }
                if (Journey_Till.equalsIgnoreCase("GAD1 Financial Details")) {
                    flag = true;
                    break Execution;
                }
                // GAD1 Property Details page

                Select selectPropertyLocated = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Property_Region"))));
                selectPropertyLocated.selectByVisibleText("London");

                Select selectProertyType = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Type_of_Property"))));
                selectProertyType.selectByVisibleText("Detached house");


                Select selectPropertyOld = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "How_old_property"))));
                selectPropertyOld.selectByVisibleText("Up to 8 years");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Property_occupied"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_outgoing")))
                    .sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_contractual")))
                    .sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Borrowing_required"))).sendKeys(
                    "53000");
                if (gettestdata("Buyer_Type").equalsIgnoreCase("Change Owner")) {
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_outgoing_rental"))).sendKeys("200");
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Rental_Income"))).sendKeys(
                        "200");
                }
                if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_radiobutton")))
                        .click();
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_propertyvalue")))
                    .sendKeys("3000000");

                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                    Select Purpose_of_loan = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Property_Details_Page", "Purpose_of_loan"))));
                    Purpose_of_loan.selectByVisibleText("Home improvement only");
                }

                Select selectPreferPay = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Repayment_dropdown"))));
                selectPreferPay.selectByVisibleText(gettestdata("Repayment_Type"));


                Select selectMortgageYY = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Mortgage_term_years"))));
                selectMortgageYY.selectByVisibleText("20");

                Select selectMortgageMM = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Mortgage_term_months"))));
                selectMortgageMM.selectByVisibleText("6");
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "other_Currency_Income_No")))
                        .click();
                } catch (Exception E) {
                }
                // Display_Popup("FCY Setup",
                // "click ok after you are done selecting fcy");

                Framework.log_report("PASS", "GAD1 Property Details Complete", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue1_button"))).click();
                if (Journey_Till.equalsIgnoreCase("GAD1 Property Details")) {
                    flag = true;
                    break Execution;
                }

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue2_button"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Confirm_checkbox"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue3_button"))).click();
                Framework.log_report("PASS", "DIP Complete", "Yes");
                if (Journey_Till.equalsIgnoreCase("DIP")) {
                    flag = true;
                    break Execution;
                }

                List<WebElement> LTV = Framework.driver.findElements(By.className("csCol-3"));
                for (WebElement element : LTV) {
                    System.out.println(element.getText());
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue4_button"))).click();
            }
            // Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page",
            // "Save_and_Continue"))).click();

            if (gettestdata("Property_Type").equalsIgnoreCase("Second Home")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "EP_Continue"))).click();
                } catch (Exception e) {
                }
            }
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "existing_prop"))).click();
                Framework.log_report("PASS", "Existing Property Page", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "existing_prop_Continue"))).click();
            } catch (Exception e) {
            }
            // Quotes
            Select selectscheme = new Select(
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Prop_purchase_scheme"))));
            selectscheme.selectByVisibleText("No");
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Transfer my mortgage to HSBC")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "owned_more_than_6months_yes"))).click();

            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Select selectMortgagType = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "Borrowmore_ProductRange"))));
                selectMortgagType.selectByVisibleText("Fixed");
            } else if (gettestdata("Buyer_Type").equalsIgnoreCase("Change Owner")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Change_borrowing_Yes"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "revised_amount"))).sendKeys("10000");
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "save_amount"))).click();
                try {
                    Select selectdepositfrom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                        "Deposit_Source_changeowner"))));
                    selectdepositfrom.selectByVisibleText("Savings");
                } catch (Exception e) {
                }
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "extra_borrowing_no"))).click();
                    Select selectsurplus = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                        "surplus_purpose"))));
                    selectsurplus.selectByVisibleText("Home improvement only");

                    Select selectsurplus_addloan = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                        "add_loan_product_range"))));
                    selectsurplus_addloan.selectByVisibleText("Fixed");
                    Select selectsurplus_repayment_type = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                        "surplus_ADD_Loan_Repayment_dropdown"))));
                    selectsurplus_repayment_type.selectByVisibleText(gettestdata("Repayment_Type"));

                    Select selectMortgageYY = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                        "surplus_ADD_Loan_Mortgage_term_years"))));
                    selectMortgageYY.selectByVisibleText("20");

                    Select selectMortgageMM = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                        "surplus_ADD_Loan_Mortgage_term_months"))));
                    selectMortgageMM.selectByVisibleText("6");
                    Library.HOL_Flag = true;

                } catch (Exception e) {
                }

            } else if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "propertyvalue"))).sendKeys("1000000");
            } else {
                Select whats_this_for = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "ProductRange"))));
                whats_this_for.selectByVisibleText("Fixed");
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "propertyvalue"))).sendKeys("1000000");
                Select selectMortgagType = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "Whats_this_for_BTL"))));
                selectMortgagType.selectByVisibleText("Other debt consolidation");
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "add_funds_to_borrow"))).sendKeys("100000");
                Select selectPreferPay = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "ADD_Loan_Repayment_dropdown"))));
                selectPreferPay.selectByVisibleText(gettestdata("Repayment_Type"));


                Select selectMortgageYY = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "ADD_Loan_Mortgage_term_years"))));
                selectMortgageYY.selectByVisibleText("20");

                Select selectMortgageMM = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "ADD_Loan_Mortgage_term_months"))));
                selectMortgageMM.selectByVisibleText("6");

            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")) {
                try {
                    Select selectprop_age = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Prop_Age"))));
                    selectprop_age.selectByVisibleText("More than 10 years");
                } catch (Exception e) {
                }
            }
            Framework.log_report("PASS", "MPD Page", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "SARSaveContinue"))).click();
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Existing_Mortgage_dropdown"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "View_Edit_Details"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Terms"))).click();

                Select select_terms = new Select(
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Terms_Years"))));
                String s = select_terms.getFirstSelectedOption().getText();
                String[] s2 = s.split(" yrs");
                int y = Integer.parseInt(s2[0]);
                y--;
                select_terms.selectByVisibleText(Integer.toString(y) + " yrs");
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Edit_Terms_Save"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Continue"))).click();

            } else {
                // Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                // "SARSaveContinue"))).click();
                List<WebElement> Continue_creating_mortgage = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                    "Continue_creating_mortgage")));
                for (int i = 0; i < Continue_creating_mortgage.size(); i++) {
                    if (Continue_creating_mortgage.get(i).isDisplayed() && Continue_creating_mortgage.get(i).isEnabled()) {
                        Continue_creating_mortgage.get(i).click();
                        i = Continue_creating_mortgage.size();
                    }
                }

                Library.Select_Loan();
                if (Library.HOL_Flag == true) {

                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Selected_HOL"))).click();
                    Framework.driver.findElement(By.xpath("//input[@value='Choose a HOL rate']")).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "ChooseHOL"))).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Select_random_Rates"))).click();
                }


                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Continue_existing_borrowmore"))).click();
                } else {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Continue"))).click();
                }
            }
            /*
             * if (gettestdata("Buyer_Type").equalsIgnoreCase(
             * "Buy my first property" ) ||
             * gettestdata("Buyer_Type").equalsIgnoreCase(
             * "Transfer my mortgage to HSBC")) {
             */
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Incentive"))).click();
            } catch (Exception e) {
            }
            // }
            List<WebElement> LoanCapital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanCapital")));
            List<WebElement> LoanRecalc = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanRecalc")));
            for (int i = 0; i < LoanCapital.size(); i++) {
                LoanCapital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanCapital")));
                Select selectQuotes = new Select(LoanCapital.get(i));
                selectQuotes.selectByVisibleText("Pay fee up-front");
                LoanRecalc = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanRecalc")));
                LoanRecalc.get(i).click();

            }

            if (gettestdata("Repayment_Type").equalsIgnoreCase("Interest only")) {
                List<WebElement> Adhoc_capital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "Adhoc_capital")));
                for (int i = 0; i < Adhoc_capital.size(); i++) {
                    Adhoc_capital.get(i).click();
                }
                try {
                    if (Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "foreignCurrencyRadio_no"))).isDisplayed()
                        && Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "foreignCurrencyRadio_no"))).isEnabled()) {
                        List<WebElement> foreigncurrency_radio = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                            "foreignCurrencyRadio_no")));
                        for (int i = 0; i < foreigncurrency_radio.size(); i++) {
                            foreigncurrency_radio.get(i).click();
                        }
                    }
                } catch (Exception E) {
                }
            }
            // Display_Popup("FCY Setup",
            // "click ok after you are done selecting fcy");
            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "SaveContinue"))).click();
            Framework.log_report("PASS", "Quotes Complete", "Yes");

            if (Journey_Till.equalsIgnoreCase("Quote Summary")) {
                flag = true;
                break Execution;
            }
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Apply"))).click();
            } catch (Exception E) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Apply_EO_Flow"))).click();
            }
            List<WebElement> Countinue_without_Booking_Rates = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                "Countinue_without_Booking_Rates")));
            for (int i = 0; i < Countinue_without_Booking_Rates.size(); i++) {
                if (Countinue_without_Booking_Rates.get(i).isDisplayed() && Countinue_without_Booking_Rates.get(i).isEnabled()) {
                    Countinue_without_Booking_Rates.get(i).click();
                    i = Countinue_without_Booking_Rates.size();
                }
            }


            // GAD 2 Personal Details
            WebElement mothername = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
                "Mothers_Name")));
            Library.enter_data(mothername, "sdfjndj");
            if (Library.url.equalsIgnoreCase("eu461")) {
                Select birth_country = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
                    "country_of_birth"))));
                Library.select_dropdown(birth_country, "United Kingdom");
                Framework.driver
                    .findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "existing_relationship_hsbc_no"))).click();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "Public_Official_opt1"))).click();

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Select selectcurrentLiving1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "Residential_Status"))));
                selectcurrentLiving1.selectByVisibleText("Live in a property I own");


                Select selectStatus1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page",
                    "Marital_dropdown"))));
                selectStatus1.selectByVisibleText("Single");

                Select selectDependent1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Personal_Details_Page", "No_of_dependent"))));
                selectDependent1.selectByVisibleText("0");

            }
            Select no_of_BTL = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
                "No_of_BTL"))));
            no_of_BTL.selectByVisibleText("None");
            Framework.log_report("PASS", "GAD2 Personal Details Complete", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "continue"))).click();


            // GAD2 Personal Details for Coapplicant
            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                WebElement mothername1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
                    "Mothers_Name")));
                Library.enter_data(mothername1, "sdfjndj");
                if (Library.url.equalsIgnoreCase("eu461")) {
                    Select birth_country1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD2_Personal_Details_Page", "country_of_birth"))));
                    Library.select_dropdown(birth_country1, "United Kingdom");
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("GAD2_Personal_Details_Page", "existing_relationship_hsbc_no"))).click();
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "Public_Official_opt1"))).click();

                if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                    Select selectcurrentLiving1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Residential_Status"))));
                    selectcurrentLiving1.selectByVisibleText("Live in a property I own");


                    Select selectStatus1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "Marital_dropdown"))));
                    selectStatus1.selectByVisibleText("Single");

                    Select selectDependent1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Personal_Details_Page", "No_of_dependent"))));
                    selectDependent1.selectByVisibleText("0");
                    /*
                     * Select selectByutoLet1 = new
                     * Select(Framework.driver.findElement
                     * (By.xpath(getobjectdata( "GAD1_Personal_Details_Page",
                     * "Other_resident"))));
                     * selectByutoLet1.selectByVisibleText("None");
                     */
                }
                Select no_of_BTL1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page",
                    "No_of_BTL"))));
                no_of_BTL1.selectByVisibleText("None");
                Framework.log_report("PASS", "GAD2 Personal Details for co-applicant Complete", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Personal_Details_Page", "continue"))).click();

            }
            if (Journey_Till.equalsIgnoreCase("GAD2 Personal Details")) {
                flag = true;
                break Execution;
            }

            // GAD2 Financial Details Page

            WebElement compname = Framework.driver.findElement(By
                .xpath(getobjectdata("GAD2_Financial_Details_Page", "Company_Name")));
            Library.enter_data(compname, "HSBC");

            WebElement comppost = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                "Company_Postcode")));
            Library.enter_data(comppost, "S1 3GG");
            if (Library.prefilled_flag == false) {
                boolean add_flag = true;
                while (add_flag) {
                    try {
                        Framework.driver
                            .findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Company_find_address"))).click();
                        Select selectBuilder = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                            "GAD2_Financial_Details_Page", "Company_address_listbox"))));
                        // selectBuilder.selectByVisibleText("S2 3GG,76,Heeley Bank Road,Sheffield,");
                        selectBuilder.selectByIndex(1);
                        add_flag = false;
                    } catch (Exception E) {
                        add_flag = true;
                    }
                }
            }

            Select selectPaid = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                "Income_frequency"))));
            Library.select_dropdown(selectPaid, "Every month");

            Select selectPaidinBank = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                "Income_Method"))));
            Library.select_dropdown(selectPaidinBank, "Direct to Bank / BACS");

            // driver.findElement(By.id("viewns_7_ULDKAB1A08DL90AETC226SH952_:financialdetai1form:grossannualincometextbox-field")).sendKeys("20000");

            WebElement Bonus = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Bonus_income")));
            Library.enter_data(Bonus, "20");
            // driver.findElement(By.id("viewns_7_ULDKAB1A08DL90AETC226SH952_:financialdetai1form:otherincometextbox-field")).sendKeys("20");

            WebElement ret_age = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                "Retirement_Age")));
            Library.enter_data(ret_age, "85");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Confirm_radio_button"))).click();

            Framework.driver.findElement(
                By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Employment_pending_changes_radiobutton"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Permanent_Emp_Radiobutton")))
                .click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Dividend_Annual_Income")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "StateBenifit_Annual_Income")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Annual_Investment"))).sendKeys("0");

            Select selectAccount = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                "bank_dropdown"))));
            Library.select_dropdown(selectAccount, "Other");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Current_Account_with_other")))
                .click();

            Select selectDebitCard = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                "number_of_Debitcard"))));
            Library.select_dropdown(selectDebitCard, "1");


            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "number_of_Creditcard"))).sendKeys(
                "0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "counsil_tax"))).sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "utilities"))).sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "buildinginsurance"))).sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "otherinsurance"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "assurancecosts"))).sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "savingsandinvestmentcost")))
                .sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "pension"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "intend_to_repay"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "ground_rent"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "essential_travel_costs")))
                .sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "non_essential_travel_cost")))
                .sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "housekeeping"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "packagecost"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "childmaintainance"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "alimony_costs"))).sendKeys("0");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "child_care_costs"))).sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "school_college_fees"))).sendKeys(
                "0");

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")) {

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Other_Income")))
                    .sendKeys("200");
                Select selectBank1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Time_with_Bank_Years_repayment_type"))));
                selectBank1.selectByVisibleText("10");

                Select selectBankmm1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Financial_Details_Page", "Time_with_Bank_Month_repayment_type"))));
                selectBankmm1.selectByVisibleText("10");
                Select selectDC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Number_of_Debit_cards"))));
                Library.select_dropdown(selectDC1, "1");

                Select selectCC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Number_of_Credit_cards"))));
                Library.select_dropdown(selectCC1, "1");

            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {

                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Other_Income")))
                    .sendKeys("200");
                Select selectBank1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Time_with_Bank_Years_repayment_type"))));
                selectBank1.selectByVisibleText("10");

                Select selectBankmm1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Financial_Details_Page", "Time_with_Bank_Month_repayment_type"))));
                selectBankmm1.selectByVisibleText("10");
                Select selectDC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                    "Number_of_Debit_cards"))));
                Library.select_dropdown(selectDC1, "1");

            }


            Framework.log_report("PASS", "GAD2 Financial Details Complete", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "continue1_button"))).click();

            try {
                List<WebElement> l = Framework.driver.findElements(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "how_to_pay")));
                // System.out.println(l.size() +
                // "****************************************");
                for (int i = 0; i < l.size(); i++) {
                    Thread.sleep(1000);
                    Select how_to_pay = new Select(l.get(i));
                    try {
                        how_to_pay.selectByVisibleText("No,I won't pay this");
                    } catch (Exception e) {
                        how_to_pay.selectByVisibleText("No, I won't pay this");
                    }
                    // System.out.println("i=" + i);
                }
            } catch (Exception e) {
                System.out.println("Inside catch");
                e.printStackTrace();
            }

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "continue2_button"))).click();


            // GAD2 Financial Details Page for coapplicant

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {

                try {
                    Select selectEmployment1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Emp_Status"))));
                    Library.select_dropdown(selectEmployment1, "Employed - full time");
                } catch (Exception E) {
                }

                WebElement compname1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Company_Name")));
                Library.enter_data(compname1, "HSBC");

                WebElement comppost1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Company_Postcode")));
                Library.enter_data(comppost1, "S1 3GG");
                if (Library.prefilled_flag == false) {
                    boolean add_flag = true;
                    while (add_flag) {
                        try {
                            Framework.driver.findElement(
                                By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Company_find_address"))).click();
                            Select selectBuilder = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                                "GAD2_Financial_Details_Page", "Company_address_listbox"))));
                            // selectBuilder.selectByVisibleText("S2 3GG,76,Heeley Bank Road,Sheffield,");
                            selectBuilder.selectByIndex(1);
                            add_flag = false;
                        } catch (Exception E) {
                            add_flag = true;
                        }
                    }
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Confirm_radio_button")))
                    .click();

                Framework.driver.findElement(
                    By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Employment_pending_changes_radiobutton"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Permanent_Emp_Radiobutton")))
                    .click();

                Select selectPaid1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Income_frequency"))));
                Library.select_dropdown(selectPaid1, "Every month");

                Select selectPaidinBank1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD2_Financial_Details_Page", "Income_Method"))));
                Library.select_dropdown(selectPaidinBank1, "Direct to Bank / BACS");

                // driver.findElement(By.id("viewns_7_ULDKAB1A08DL90AETC226SH952_:financialdetai1form:grossannualincometextbox-field")).sendKeys("20000");

                WebElement Bonus1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Bonus_income")));
                Library.enter_data(Bonus1, "20");
                // driver.findElement(By.id("viewns_7_ULDKAB1A08DL90AETC226SH952_:financialdetai1form:otherincometextbox-field")).sendKeys("20");

                WebElement ret_age1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                    "Retirement_Age")));
                Library.enter_data(ret_age1, "85");


                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Dividend_Annual_Income")))
                    .sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "StateBenifit_Annual_Income")))
                    .sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Annual_Investment"))).sendKeys(
                    "0");

                Select selectAccount1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD2_Financial_Details_Page", "bank_dropdown"))));
                selectAccount1.selectByVisibleText("Other");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "Current_Account_with_other")))
                    .click();

                Select selectDebitCard1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD2_Financial_Details_Page", "number_of_Debitcard"))));
                selectDebitCard1.selectByVisibleText("0");


                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "number_of_Creditcard")))
                    .sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "counsil_tax"))).sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "utilities"))).sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "buildinginsurance"))).sendKeys(
                    "0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "otherinsurance")))
                    .sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "assurancecosts")))
                    .sendKeys("0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "savingsandinvestmentcost")))
                    .sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "pension"))).sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "intend_to_repay"))).sendKeys(
                    "0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "ground_rent"))).sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "essential_travel_costs")))
                    .sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "non_essential_travel_cost")))
                    .sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "housekeeping"))).sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "packagecost"))).sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "childmaintainance"))).sendKeys(
                    "0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "alimony_costs"))).sendKeys("0");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "child_care_costs"))).sendKeys(
                    "0");

                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "school_college_fees")))
                    .sendKeys("0");
                if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {


                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Other_Income"))).sendKeys(
                        "200");
                    Select selectBank1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Time_with_Bank_Years_repayment_type"))));
                    selectBank1.selectByVisibleText("10");

                    Select selectBankmm1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Time_with_Bank_Month_repayment_type"))));
                    selectBankmm1.selectByVisibleText("10");
                    Select selectDC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Number_of_Debit_cards"))));
                    Library.select_dropdown(selectDC1, "1");
                    try {
                        Select selectCC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                            "GAD1_Financial_Details_Page", "Number_of_Credit_cards"))));
                        Library.select_dropdown(selectCC1, "1");
                    } catch (Exception E) {
                    }
                    Select selectWorkingArea1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Emp_Business"))));
                    Library.select_dropdown(selectWorkingArea1, "Computers & Telecommunications");


                    Select selectOccupation1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Occupation_Type"))));
                    Library.select_dropdown(selectOccupation1, "Manual - Supervisory");

                    Select selectSepcificOCC1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                        "GAD1_Financial_Details_Page", "Specific_occupation"))));
                    Library.select_dropdown(selectSepcificOCC1, "Agricultural worker");
                    WebElement jobtitle1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Job_Title")));
                    Library.enter_data(jobtitle1, "audsjhidbq");

                    WebElement empstartdate1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Day")));
                    // Library.enter_data(empstartdate1, "15");
                    empstartdate1.clear();
                    empstartdate1.sendKeys("15");

                    WebElement empstartmonth1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Month")));
                    // Library.enter_data(empstartmonth1, "05");
                    empstartmonth1.clear();
                    empstartmonth1.sendKeys("05");
                    WebElement empstartyear1 = Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page",
                        "Emp_Startdate_Year")));
                    // Library.enter_data(empstartyear1, "2000");
                    empstartyear1.clear();
                    empstartyear1.sendKeys("2000");
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income")))
                        .clear();
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Financial_Details_Page", "Gross_Annual_Income")))
                        .sendKeys(gettestdata("Salary"));
                }

                Framework.log_report("PASS", "GAD2 Financial Details for co-applicant Complete", "Yes");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "continue1_button"))).click();
                try {
                    List<WebElement> l = Framework.driver.findElements(By.xpath(getobjectdata("GAD2_Financial_Details_Page",
                        "how_to_pay")));
                    // System.out.println(l.size() +
                    // "****************************************");
                    for (int i = 0; i < l.size(); i++) {
                        Thread.sleep(1000);
                        Select how_to_pay = new Select(l.get(i));
                        try {
                            how_to_pay.selectByVisibleText("No,I won't pay this");
                        } catch (Exception e) {
                            how_to_pay.selectByVisibleText("No, I won't pay this");
                        }
                        // System.out.println("i=" + i);
                    }
                } catch (Exception e) {
                    System.out.println("Inside catch");
                    e.printStackTrace();
                }
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD2_Financial_Details_Page", "continue2_button")))
                        .click();
                } catch (Exception e) {
                }
            }
            if (Journey_Till.equalsIgnoreCase("GAD2 Financial Details")) {
                flag = true;
                break Execution;
            }

            // GAD 2 Property details page
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropAddrText"))).sendKeys("S1 3GG");

                boolean add_flag = true;
                while (add_flag) {
                    try {
                        Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "FindAddr"))).click();
                        Select selectPropertyAddress = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                            "GAD2Property", "PropAddrList"))));
                        selectPropertyAddress.selectByIndex(1);
                        add_flag = false;
                    } catch (Exception e) {
                        add_flag = true;
                    }
                }
            } catch (Exception e) {
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Term or repayment type change")) {
                Select selectProertyType1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Type_of_Property"))));
                selectProertyType1.selectByVisibleText("Detached house");


                Select selectPropertyOld1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "How_old_property"))));
                selectPropertyOld1.selectByVisibleText("Up to 8 years");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Property_occupied"))).click();
            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Select selectProertyType1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "Type_of_Property"))));
                selectProertyType1.selectByVisibleText("Detached house");


                Select selectPropertyOld1 = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "GAD1_Property_Details_Page", "How_old_property"))));
                selectPropertyOld1.selectByVisibleText("Up to 8 years");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Property_occupied"))).click();
                Framework.driver.findElement(
                    By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_outgoing_rental"))).sendKeys("200");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Rental_Income")))
                    .sendKeys("200");
            }
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Is_Property_let_to_relative"))).click();
            } catch (Exception e) {
            }
            Select selectTenure = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Tenure"))));
            selectTenure.selectByVisibleText("Freehold");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropConv"))).click();

            Select selectBeddRom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "NumofBedroom"))));
            selectBeddRom.selectByVisibleText("2");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropListed"))).click();

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Transfer my mortgage to HSBC")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Change Owner")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "other_loan_amount"))).sendKeys("0");
            }
            try {
                Select selectPropertyConstructed = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                    "PropConstr_EO"))));
                selectPropertyConstructed.selectByVisibleText("Timber Frame");
            } catch (Exception e) {
                Select selectPropertyConstructed = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                    "PropConstr_Agent"))));
                selectPropertyConstructed.selectByVisibleText("Timber Frame");
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "EstPrice"))).sendKeys("3000000");
                Select selectDepositFrom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                    "MethodDeposit"))));
                selectDepositFrom.selectByVisibleText("Savings");
            }

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")
                && gettestdata("Property_Type").equalsIgnoreCase("Second Home")) {
                Select selectScheme = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Scheme"))));
                selectScheme.selectByVisibleText("No");
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow more(Existing)")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "other_loan_amount"))).sendKeys("0");
            }
            try {
                WebElement title = Framework.driver.findElement(By.xpath("//select[contains(@id,'existingownertitledropdown')]"));
                Select select_title = new Select(title);
                select_title.selectByVisibleText("Mr");
            } catch (Exception e) {
            }
            Framework.log_report("PASS", "GAD2 Property Details Complete", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continue"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continuenav"))).click();


            if (Journey_Till.equalsIgnoreCase("GAD2 Property Details")) {
                flag = true;
                break Execution;
            }

            // FCD
            Framework.driver.findElement(By.xpath(getobjectdata("FCD", "Confirm_checkbox"))).click();

            try {
                if (Framework.driver.findElement(By.xpath("//input[contains(@id,'fcdCraAgreementForm:ilacheckbox-option_1')]"))
                    .isDisplayed()
                    || Framework.driver.findElement(By.xpath("//input[contains(@id,'fcdCraAgreementForm:ilacheckbox-option_1')]"))
                        .isEnabled()) {
                    Framework.driver.findElement(By.xpath("//input[contains(@id,'fcdCraAgreementForm:ilacheckbox-option_1')]"))
                        .click();
                }
            } catch (Exception e) {
            }

            Framework.driver.findElement(By.xpath(getobjectdata("FCD", "FCDCRA"))).click();

            if (Journey_Till.equalsIgnoreCase("FCD")) {
                flag = true;
                break Execution;
            }
            // Valuation Page
            Common_Functions.Complete_Valuation();

            if (Journey_Till.equalsIgnoreCase("Valuation")) {
                flag = true;
                break Execution;
            }

            // Conveyancing Details Page
            Common_Functions.Complete_ConveyancingDetails();

            if (Journey_Till.equalsIgnoreCase("Conveyancing Details")) {
                flag = true;
                break Execution;
            }
            // DD page
            Common_Functions.Complete_DD();

            if (Journey_Till.equalsIgnoreCase("DD")) {
                flag = true;
                break Execution;
            }

            if (Env.equalsIgnoreCase("UAT")) {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
            }


            // Application Maintenance

            Common_Functions.Complete_Application_Maintenance();

            // Document and Correspondence

            Common_Functions.Complete_Document_and_Correspondence();

            // Pay Fees
            Common_Functions.Pay_Fees();

            boolean condition = false;
            if (Journey_Till.equalsIgnoreCase("Payments")) {
                flag = true;
                break Execution;
            }
            try {
                condition = Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "PropVal"))).isDisplayed();
                System.out.println(condition);
            } catch (Exception E) {
            }
            if (condition) {
                String Testharness_result = MQ_Test_Harness.MQTestHarness(app_id);
                if (Testharness_result.equalsIgnoreCase("return code=0")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "PropVal"))).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "ValConfirm"))).click();
                } else {
                    System.out.println("***MQTESTHARNESS Return code not equal to 0");
                    // Framework.driver.quit();
                }
            }

            boolean status_condition = false;

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "joint_app_radio"))).click();
                } catch (Exception e) {
                    if (Env.equalsIgnoreCase("UAT")) {

                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                    } else {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    }
                    Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "joint_app_radio"))).click();
                }
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "refresh_page"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "jms_next_step"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("Joint_Applicant", "confirm_joint_app_details"))).click();
                try {
                    if (Env.equalsIgnoreCase("UAT")) {

                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                    } else {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    }
                } catch (Exception E) {
                    if (Env.equalsIgnoreCase("UAT")) {

                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                    } else {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    }
                }
                try {
                    // Speak to Mortgage Advisor
                    Framework.driver.findElement(By.xpath(getobjectdata("Speak_to_Advisor", "checkbox_coapp"))).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Speak_to_Advisor", "submit_coapp"))).click();
                } catch (Exception e) {
                }

                try {
                    Framework.driver.findElement(By.xpath("//input[contains(@id, MarktgPref_SelMany_CBox_1)]")).click();
                } catch (Exception E) {
                }

                parent = Framework.driver.getWindowHandle();
                Framework.driver.findElement(By.xpath(getobjectdata("Joint_Applicant", "init_disclosure_doc"))).click();
                Thread.sleep(5000);
                Framework.driver.switchTo().window(parent);
                Thread.sleep(1000);
                Framework.driver.findElement(By.xpath(getobjectdata("Joint_Applicant", "continue"))).click();

                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer"))).click();

                try {
                    Thread.sleep(1000);
                    if (Env.equalsIgnoreCase("UAT")) {

                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                    } else {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    }
                } catch (Exception E) {
                    Thread.sleep(1000);
                    if (Env.equalsIgnoreCase("UAT")) {

                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                    } else {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    }
                }
                String Status = Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "what_done_so_far"))).getText();
                status_condition = Status.toLowerCase().contains("mortgage offer generated")
                    || Status.toLowerCase().contains("mortgage offer created");
            } else {
                if (condition) {
                    Thread.sleep(1000);
                    try {
                        if (Env.equalsIgnoreCase("UAT")) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                        } else {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                        }
                    } catch (Exception E) {
                        if (Env.equalsIgnoreCase("UAT")) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                        } else {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                        }
                    }
                    try {
                        if (Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer")))
                            .isDisplayed()
                            && Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer")))
                                .isEnabled()) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer"))).click();
                            if (Env.equalsIgnoreCase("UAT")) {

                                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                            } else {
                                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                            }
                        }
                    } catch (Exception E) {

                    }
                    String Status = Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "what_done_so_far"))).getText();
                    System.out.println(Status.toLowerCase());
                    status_condition = Status.toLowerCase().contains("mortgage offer generated")
                        || Status.toLowerCase().contains("mortgage offer created");
                    System.out.println("Execution Status: " + status_condition);
                } else {
                    Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "Create_Mortgage_Offer"))).click();
                    try {
                        if (Env.equalsIgnoreCase("UAT")) {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
                        } else {
                            Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                        }
                    } catch (Exception E) {
                    }
                    String Status = Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "what_done_so_far"))).getText();
                    System.out.println(Status.toLowerCase());
                    status_condition = Status.toLowerCase().contains("mortgage offer generated")
                        || Status.toLowerCase().contains("mortgage offer created");
                    System.out.println("Execution Status: " + status_condition);
                }

            }
            if (status_condition) {
                Framework.log_report("PASS", "Offer Generation Complete", "No");
                Framework.log_report("PASS", "Data Staging Complete", "Yes");
                System.out.println("Executon Completed");
                update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");

                // Display_Popup("Thank You!!!", "Execution Complete");
            } else {
                // takeScreenshot("Agent_Error_Page");
                // Display_Popup("Error!!!", "Execution Failed");
                update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "FAIL");
            }

        } catch (Exception E) {
            // takeScreenshot("Agent_Error_Page");
            E.printStackTrace();
            // Display_Popup("Error!!!", "Execution Failed");
            Framework.log_report("FAIL", "Execution Failed", "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "FAIL");
        }
        if (flag) {
            System.out.println("Execution done till:" + Journey_Till);
            Framework.log_report("PASS", "Journey Complete till " + Journey_Till, "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");
        }

    }

}
