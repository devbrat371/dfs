/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package End_to_End_Flow;

import java.text.DecimalFormat;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Common_Library.Common_Functions;
import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Customer_Advised_Journey extends Framework {
    public static void Customer_Advised_Flow() throws Exception {
        double startTime = System.currentTimeMillis();

        String Env = Library.Environment;
        String app_id;
        Boolean flag = false;
        String Journey_Till;

        Journey_Till = gettestdata("Journey_Till");

        System.out.println("######Customer Journey######");
        Library.startSelenium("Customer_Channel");
        if ((Env.equalsIgnoreCase("SIT") && (Library.url.equalsIgnoreCase("hk74") || Library.url.equalsIgnoreCase("eu474")))
            || Env.equalsIgnoreCase("DIT")) {
            Framework.driver.findElement(By.xpath("//a[text()='Triage Receive']")).click();

        }
        Execution: try {
            Framework.log_report("PASS", "HealthCheck Journey Started on: " + Library.url, "No");
            // Before you Start
            Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "Triage_Response_1"))).click();
            if (Env.equalsIgnoreCase("DIT") || Library.url.equalsIgnoreCase("hk375")) {
                try {
                    if (Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "captcha"))).isDisplayed()
                        || Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "captcha"))).isEnabled()) {
                        String captchatext = Display_InputPopup();
                        Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "captcha_text"))).sendKeys(
                            captchatext);
                    }
                } catch (Exception e) {
                }
            }

            List<WebElement> continue_button = Framework.driver.findElements(By.xpath(Framework.getobjectdata(
                "Before_Your_Start_Page", "Continue_App")));
            Thread.sleep(1000);
            for (int i = 0; i < continue_button.size(); i++) {

                if (continue_button.get(i).isDisplayed() && continue_button.get(i).isEnabled()) {
                    continue_button.get(i).click();
                    i = continue_button.size();
                }
            }
            // What would you like to do
            if (gettestdata("Property_Type").equalsIgnoreCase("Main Home")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "property_option1"))).click();

                Select selectLooking = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "What_would_you_like_to_do_Page", "buyertype_mainhome"))));
                selectLooking.selectByVisibleText(gettestdata("Buyer_Type"));

                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow extra - for EXISTING customers")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("What_would_you_like_to_do_Page", "debtConsolidationMainHome_Yes"))).click();
                } else {
                    Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "Right_to_buy_yes")))
                        .click();
                }
            }

            else if (gettestdata("Property_Type").equalsIgnoreCase("Second Home")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "property_option2"))).click();

                Select selectLooking = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                    "What_would_you_like_to_do_Page", "buyertype_secondhome"))));
                selectLooking.selectByVisibleText(gettestdata("Buyer_Type"));

                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow extra - for EXISTING customers")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("What_would_you_like_to_do_Page", "debtConsolidationSecondHome_Yes"))).click();
                }
            }

            else if (gettestdata("Property_Type").equalsIgnoreCase("BTL")) {
                Display_Popup("OOPS!!!", "You Cannot Select BTL option for Advised Flow");
                Framework.driver.quit();
            }
            Thread.sleep(5000);
            Framework.log_report("PASS", "Service Type Page", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "submit"))).click();
            String parent = Framework.driver.getWindowHandle();

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "advice_flow_button"))).click();
            Thread.sleep(5000);


            Framework.driver.switchTo().window(parent);


            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continuewithadvice_button")))
                .click();

            // Who's Applying
            Common_Functions.Fill_Customer_Details();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "Add_Customer"))).click();
                Common_Functions.Fill_Customer_Details();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "save_and_continue"))).click();
            // Your Security Details
            Common_Functions.Security_Details();

            // Application ID Generation
            if (Env.equalsIgnoreCase("UAT") || Library.url.equalsIgnoreCase("hk375")) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_save_and_exit")))
                        .click();
                } catch (Exception e) {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_save_and_exit")))
                        .click();
                }
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_confirm_exit"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "save_and_exit"))).click();
            }
            String str1 = Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Customer_app_id"))).getText();
            str1 = str1.split("pplication reference number ")[1];
            app_id = str1.split(" to any documents")[0];
            System.out.println("****App id: " + app_id);
            update_AppID(Mortgage_Data_Creation.E2E_Test.rowCount, app_id);
            Framework.log_report("PASS", "Application ID Generated:" + app_id, "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Save_and_Continue"))).click();

            // GAD1 Personal Details
            Common_Functions.Fill_NTB_GAD1_PersonalDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD1_PersonalDetails();
            }

            if (Journey_Till.equalsIgnoreCase("GAD1 Personal Details")) {
                flag = true;
                break Execution;
            }

            // GAD 1 Financial details
            Common_Functions.Fill_NTB_GAD1_FinancialDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD1_FinancialDetails();
            }

            if (Journey_Till.equalsIgnoreCase("GAD1 Financial Details")) {
                flag = true;
                break Execution;
            }

            // GAD1 Property Details page

            Select selectPropertyLocated = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                "GAD1_Property_Details_Page", "Property_Region"))));
            selectPropertyLocated.selectByVisibleText("London");

            Select selectProertyType = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Type_of_Property"))));
            selectProertyType.selectByVisibleText("Detached house");


            Select selectPropertyOld = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "How_old_property"))));
            selectPropertyOld.selectByVisibleText("Up to 8 years");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Property_occupied"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_outgoing")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_contractual")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Borrowing_required"))).sendKeys(
                "100000");


            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_radiobutton"))).click();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_propertyvalue"))).sendKeys(
                "300000");

            Select selectPreferPay = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Repayment_dropdown"))));
            selectPreferPay.selectByVisibleText(gettestdata("Repayment_Type"));

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                Select purposeofloan = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                    "Purpose_of_loan"))));
                purposeofloan.selectByVisibleText("Home improvement and more");
            }

            Select selectMortgageYY = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Mortgage_term_years"))));
            selectMortgageYY.selectByVisibleText("20");

            Select selectMortgageMM = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Mortgage_term_months"))));
            selectMortgageMM.selectByVisibleText("6");
            /*
             * // Temporary
             * Framework.driver.findElement(By.xpath(getobjectdata(
             * "GAD1_Property_Details_Page", "other_Currency_Income_Yes")))
             * .click(); Thread.sleep(20000); Select currency = new
             * Select(Framework.driver.findElement(By
             * .xpath("//select[contains(@id,'currencyOfIncomeDropdown-option')]"
             * ))); List<String> set = currency. if
             * (Journey_Till.equalsIgnoreCase("GAD1 Property Details")) { flag
             * = true; break Execution; }
             */

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "other_Currency_Income_No"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue1_button"))).click();

            if (Journey_Till.equalsIgnoreCase("GAD1 Property Details")) {
                flag = true;
                break Execution;
            }

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue2_button"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Confirm_checkbox"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue3_button"))).click();

            if (Journey_Till.equalsIgnoreCase("DIP")) {
                flag = true;
                break Execution;
            }

            List<WebElement> LTV = Framework.driver.findElements(By.className("csCol-3"));
            for (WebElement element : LTV) {
                System.out.println(element.getText());
            }
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue4_button"))).click();
            Framework.log_report("PASS", "GAD1 Property Details Complete", "No");

            Framework.driver.findElement(By.xpath("//a[@title='Provide extra details now']")).click();
            // GAD 2 Personal Details

            Common_Functions.Fill_NTB_GAD2_PersonalDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD2_PersonalDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD2 Personal Details")) {
                flag = true;
                break Execution;
            }

            // GAD2 Financial Details
            Common_Functions.Fill_NTB_GAD2_FinancialDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD2_FinancialDetails();
            }

            if (Journey_Till.equalsIgnoreCase("GAD2 Financial Details")) {
                flag = true;
                break Execution;
            }

            // GAD 2 Property details page

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropAddrText"))).sendKeys("S1 3GG");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "FindAddr"))).click();


            Select selectPropertyAddress = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                "PropAddrList"))));
            selectPropertyAddress.selectByIndex(1);

            Select selectTenure = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Tenure"))));
            selectTenure.selectByVisibleText("Freehold");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropConv"))).click();

            Select selectBeddRom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "NumofBedroom"))));
            selectBeddRom.selectByVisibleText("2");
            try {
                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")
                    || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "other_loan_amount"))).sendKeys("0");
                }
            } catch (Exception E) {
            }

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropListed"))).click();
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                try {
                    Select selectPurchaseSechem = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                        "Scheme"))));
                    selectPurchaseSechem.selectByVisibleText("No");
                } catch (Exception e) {
                }
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "EstPrice"))).sendKeys("300000");
                Select selectDepositFrom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                    "MethodDeposit"))));
                selectDepositFrom.selectByVisibleText("Savings");
            } else {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "other_loan_amount"))).sendKeys("0");
                } catch (Exception E) {
                }
            }
            Select selectPropertyConstructed = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                "PropConstr_Agent"))));
            selectPropertyConstructed.selectByVisibleText("Timber Frame");


            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continue"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continuenav"))).click();
            Framework.log_report("PASS", "GAD1 Property Details Complete", "No");
            if (Journey_Till.equalsIgnoreCase("GAD2 Property Details")) {
                flag = true;
                break Execution;
            }
            System.out.println("Execution Completed");
            double endTime = System.currentTimeMillis();
            double totalTime = endTime - startTime;
            totalTime = totalTime / 60000;
            totalTime = Double.parseDouble(new DecimalFormat("##.##").format(totalTime));
            System.out.println("Total Execution Time: " + totalTime + " Minutes");
            // Display_Popup("Thank You!!!", "Execution Complete");
            Framework.log_report("PASS", "Customer Journey Completed till DD", "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");
        } catch (Exception E) {
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "FAIL");
            E.printStackTrace();
            // Display_Popup("Error!!!", "Execution Failed");
            Framework.log_report("FAIL", "Customer HealthCheck Failed", "Yes");
        }
        if (flag) {
            System.out.println("Execution done till:" + Journey_Till);
            Framework.log_report("PASS", "Journey Complete till " + Journey_Till, "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");
        }
    }
}
