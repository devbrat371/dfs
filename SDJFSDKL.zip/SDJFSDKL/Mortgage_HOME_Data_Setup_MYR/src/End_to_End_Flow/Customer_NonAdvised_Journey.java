/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package End_to_End_Flow;

import java.text.DecimalFormat;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import Common_Library.Common_Functions;
import Mortgage_Data_Creation.MQ_Test_Harness;
import framework.Framework;
import framework.Library;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class Customer_NonAdvised_Journey extends Framework {

    @Test
    public static void Customer_NonAdvised_Flow() throws Exception {
        double startTime = System.currentTimeMillis();

        String Env = Library.Environment;
        String app_id;
        Boolean flag = false;
        String Journey_Till;

        Journey_Till = gettestdata("Journey_Till");

        System.out.println("######Customer Journey######");
        Library.startSelenium("Customer_Channel");
        if ((Env.equalsIgnoreCase("SIT") && (Library.url.equalsIgnoreCase("hk74") || Library.url.equalsIgnoreCase("eu474")))
            || Env.equalsIgnoreCase("DIT")) {
            Framework.driver.findElement(By.xpath("//a[text()='Triage Receive']")).click();

        }
        Execution: try {
            Framework.log_report("PASS", "HealthCheck Journey Started on: " + Library.url, "No");
            // Before you Start
            Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "Triage_Response_1"))).click();
            if (Env.equalsIgnoreCase("DIT") || Library.url.equalsIgnoreCase("hk375")) {
                try {
                    if (Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "captcha"))).isDisplayed()
                        || Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "captcha"))).isEnabled()) {
                        String captchatext = Display_InputPopup();
                        Framework.driver.findElement(By.xpath(getobjectdata("Before_Your_Start_Page", "captcha_text"))).sendKeys(
                            captchatext);
                    }
                } catch (Exception e) {
                }
            }

            List<WebElement> continue_button = Framework.driver.findElements(By.xpath(Framework.getobjectdata(
                "Before_Your_Start_Page", "Continue_App")));
            Thread.sleep(1000);
            for (int i = 0; i < continue_button.size(); i++) {

                if (continue_button.get(i).isDisplayed() && continue_button.get(i).isEnabled()) {
                    continue_button.get(i).click();
                    i = continue_button.size();
                }
            }
            // What would you like to do
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "property_option3"))).click();

            Select selectLooking = new Select(Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page",
                "buyertype_BTL_mainhome"))));
            selectLooking.selectByVisibleText(gettestdata("Buyer_Type"));

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "way_to_cover_mortgage")))
                    .click();
                Framework.driver
                    .findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "intend_to_occupy_property"))).click();
            } else if (gettestdata("Buyer_Type").equalsIgnoreCase("Transfer my mortgage to HSBC")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Borrow extra - for EXISTING customers")) {
                Framework.driver.findElement(
                    By.xpath(getobjectdata("What_would_you_like_to_do_Page", "way_to_cover_mortgage_transfer_borrowmore"))).click();
                Framework.driver.findElement(
                    By.xpath(getobjectdata("What_would_you_like_to_do_Page", "intend_to_occupy_property_transfer_borrowmore")))
                    .click();
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "own_other_BTL_No"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "inheritedInLastFiveYrs")))
                    .click();

                if (gettestdata("Let_out_for_business").equalsIgnoreCase("No")) {
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("What_would_you_like_to_do_Page", "Let_out_for_business_No"))).click();
                } else {
                    Framework.driver.findElement(
                        By.xpath(getobjectdata("What_would_you_like_to_do_Page", "Let_out_for_business_Yes"))).click();
                }
            }
            Framework.log_report("PASS", "Service Type Page", "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "submit"))).click();
            String parent = Framework.driver.getWindowHandle();

            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "NonAdvice_flow_button")))
                .click();
            Thread.sleep(5000);
            Framework.driver.switchTo().window(parent);
            Framework.driver.findElement(By.xpath(getobjectdata("What_would_you_like_to_do_Page", "continuewithNonadvice_button")))
                .click();


            // Who's Applying
            Common_Functions.Fill_Customer_Details();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "Add_Customer"))).click();
                Common_Functions.Fill_Customer_Details();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("Who_is_Applying_Page", "save_and_continue"))).click();

            // Your Security Details
            Common_Functions.Security_Details();

            // Application ID Generation
            if (Env.equalsIgnoreCase("UAT") || Library.url.equalsIgnoreCase("hk375")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_save_and_exit"))).click();
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "UAT_confirm_exit"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Personal_Details_Page", "save_and_exit"))).click();
            }
            String str1 = Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Customer_app_id"))).getText();
            str1 = str1.split("pplication reference number ")[1];
            app_id = str1.split(" to any documents")[0];
            System.out.println("****App id: " + app_id);
            update_AppID(Mortgage_Data_Creation.E2E_Test.rowCount, app_id);
            Framework.log_report("PASS", "Application ID Generated:" + app_id, "Yes");
            Framework.driver.findElement(By.xpath(getobjectdata("Thank_You_Page", "Save_and_Continue"))).click();

            // GAD1 Personal Details
            Common_Functions.Fill_NTB_GAD1_PersonalDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD1_PersonalDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD1 Personal Details")) {
                flag = true;
                break Execution;
            }

            // GAD 1 Financial details
            Common_Functions.Fill_NTB_GAD1_FinancialDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD1_FinancialDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD1 Financial Details")) {
                flag = true;
                break Execution;
            }

            // GAD1 Property Details page

            Select selectPropertyLocated = new Select(Framework.driver.findElement(By.xpath(getobjectdata(
                "GAD1_Property_Details_Page", "Property_Region"))));
            selectPropertyLocated.selectByVisibleText("London");

            Select selectProertyType = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Type_of_Property"))));
            selectProertyType.selectByVisibleText("Detached house");


            Select selectPropertyOld = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "How_old_property"))));
            selectPropertyOld.selectByVisibleText("Up to 8 years");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Property_occupied"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_outgoing")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_contractual")))
                .sendKeys("0");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Borrowing_required"))).sendKeys(
                "100000");


            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_radiobutton"))).click();
            }
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Based_on_propertyvalue"))).sendKeys(
                "300000");

            Select selectPreferPay = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Repayment_dropdown"))));
            selectPreferPay.selectByVisibleText(gettestdata("Repayment_Type"));

            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                Select purposeofloan = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                    "Purpose_of_loan"))));
                purposeofloan.selectByVisibleText("Home improvement and more");
            }

            Select selectMortgageYY = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Mortgage_term_years"))));
            selectMortgageYY.selectByVisibleText("20");

            Select selectMortgageMM = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page",
                "Mortgage_term_months"))));
            selectMortgageMM.selectByVisibleText("6");
            /*
             * // Temporary
             * Framework.driver.findElement(By.xpath(getobjectdata(
             * "GAD1_Property_Details_Page", "other_Currency_Income_Yes")))
             * .click(); Thread.sleep(20000); Select currency = new
             * Select(Framework.driver.findElement(By
             * .xpath("//select[contains(@id,'currencyOfIncomeDropdown-option')]"
             * ))); List<String> set = currency. if
             * (Journey_Till.equalsIgnoreCase("GAD1 Property Details")) { flag
             * = true; break Execution; }
             */
            try {
                Framework.driver.findElement(
                    By.xpath(getobjectdata("GAD1_Property_Details_Page", "Expected_Monthly_outgoing_rental"))).sendKeys("200");
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Rental_Income")))
                    .sendKeys("200");
            } catch (Exception E) {
            }

            try {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "other_Currency_Income_No")))
                    .click();
            } catch (Exception e) {
            }

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue1_button"))).click();

            if (Journey_Till.equalsIgnoreCase("GAD1 Property Details")) {
                flag = true;
                break Execution;
            }

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue2_button"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Confirm_checkbox"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue3_button"))).click();

            if (Journey_Till.equalsIgnoreCase("DIP")) {
                flag = true;
                break Execution;
            }

            List<WebElement> LTV = Framework.driver.findElements(By.className("csCol-3"));
            for (WebElement element : LTV) {
                System.out.println(element.getText());
            }
            Framework.driver.findElement(By.xpath(getobjectdata("GAD1_Property_Details_Page", "Continue4_button"))).click();
            Framework.log_report("PASS", "GAD1 Property Details Complete", "No");

            // Quotes

            if (gettestdata("Property_Type").equalsIgnoreCase("Second Home")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                try {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "EP_Continue"))).click();
                } catch (Exception e) {
                }
            }

            Select selectscheme = new Select(
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Prop_purchase_scheme"))));
            selectscheme.selectByVisibleText("No");
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Transfer my mortgage to HSBC")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "owned_more_than_6months_yes"))).click();

            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Buy my first property")
                || gettestdata("Buyer_Type").equalsIgnoreCase("Move house/Buy another property")) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Purchase_Price"))).clear();
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Purchase_Price"))).sendKeys("3000000");
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "DepositAmt"))).sendKeys("2900000");
                Select selectdepositsource = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "Deposit_Source"))));
                selectdepositsource.selectByVisibleText("Savings");
            }
            if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")) {
                Select selectMortgagType = new Select(Framework.driver.findElement(By.xpath(getobjectdata("Quotes",
                    "Borrowmore_ProductRange"))));
                selectMortgagType.selectByVisibleText("Fixed rate mortgages");
            } else {
                Select selectMortgagType = new Select(Framework.driver.findElement(By
                    .xpath(getobjectdata("Quotes", "ProductRange"))));

                selectMortgagType.selectByVisibleText("Fixed rate mortgages");
            }

            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "SARSaveContinue"))).click();
            List<WebElement> Continue_creating_mortgage = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                "Continue_creating_mortgage")));
            for (int i = 0; i < Continue_creating_mortgage.size(); i++) {
                if (Continue_creating_mortgage.get(i).isDisplayed() && Continue_creating_mortgage.get(i).isEnabled()) {
                    Continue_creating_mortgage.get(i).click();
                    i = Continue_creating_mortgage.size();
                }
            }

            Library.Select_Loan();

            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Continue"))).click();

            try {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Incentive"))).click();
            } catch (Exception e) {
            }

            List<WebElement> LoanCapital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanCapital")));
            List<WebElement> LoanRecalc = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanRecalc")));
            for (int i = 0; i < LoanCapital.size(); i++) {
                LoanCapital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanCapital")));
                Select selectQuotes = new Select(LoanCapital.get(i));
                selectQuotes.selectByVisibleText("Pay fee upfront");
                LoanRecalc = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "LoanRecalc")));
                LoanRecalc.get(i).click();

            }
            if (gettestdata("Repayment_Type").equalsIgnoreCase("Interest only")) {
                List<WebElement> Adhoc_capital = Framework.driver.findElements(By.xpath(getobjectdata("Quotes", "Adhoc_capital")));
                for (int i = 0; i < Adhoc_capital.size(); i++) {
                    Adhoc_capital.get(i).click();
                }
                try {
                    if (Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "foreignCurrencyRadio_no"))).isDisplayed()
                        && Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "foreignCurrencyRadio_no"))).isEnabled()) {
                        List<WebElement> foreigncurrency_radio = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                            "foreignCurrencyRadio_no")));
                        for (int i = 0; i < foreigncurrency_radio.size(); i++) {
                            foreigncurrency_radio.get(i).click();
                        }
                    }
                } catch (Exception E) {
                }
            }
            Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "SaveContinue"))).click();
            if (Journey_Till.equalsIgnoreCase("Quote Summary")) {
                flag = true;
                break Execution;
            }
            try {
                if (gettestdata("Buyer_Type").equalsIgnoreCase("Borrow funds - for NEW customers")
                    || Library.url.equalsIgnoreCase("hk375")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Apply"))).click();
                } else {
                    Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Apply_EO_Flow"))).click();
                }
            } catch (Exception e) {
                Framework.driver.findElement(By.xpath(getobjectdata("Quotes", "Apply"))).click();
            }
            List<WebElement> Countinue_without_Booking_Rates = Framework.driver.findElements(By.xpath(getobjectdata("Quotes",
                "Countinue_without_Booking_Rates")));
            for (int i = 0; i < Countinue_without_Booking_Rates.size(); i++) {
                if (Countinue_without_Booking_Rates.get(i).isDisplayed() && Countinue_without_Booking_Rates.get(i).isEnabled()) {
                    Countinue_without_Booking_Rates.get(i).click();
                    i = Countinue_without_Booking_Rates.size();
                }
            }
            try {
                if (Env.equalsIgnoreCase("UAT")) {
                    Framework.driver.findElement(By.xpath("//input[@value='Continue without securing rate']")).click();
                }
            } catch (Exception e) {
            }

            Framework.log_report("PASS", "Quotes Complete", "No");
            // GAD 2 Personal Details

            Common_Functions.Fill_NTB_GAD2_PersonalDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD2_PersonalDetails();
            }
            if (Journey_Till.equalsIgnoreCase("GAD2 Personal Details")) {
                flag = true;
                break Execution;
            }

            // GAD2 Financial Details
            Common_Functions.Fill_NTB_GAD2_FinancialDetails();

            if (gettestdata("Joint Applicant").equalsIgnoreCase("Yes")) {
                Common_Functions.Fill_NTB_GAD2_FinancialDetails();
            }

            if (Journey_Till.equalsIgnoreCase("GAD2 Financial Details")) {
                flag = true;
                break Execution;
            }

            // GAD 2 Property details page

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropAddrText"))).sendKeys("S1 3GG");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "FindAddr"))).click();


            Select selectPropertyAddress = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                "PropAddrList"))));
            selectPropertyAddress.selectByIndex(1);

            Select selectTenure = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Tenure"))));
            selectTenure.selectByVisibleText("Freehold");

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropConv"))).click();

            Select selectBeddRom = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "NumofBedroom"))));
            selectBeddRom.selectByVisibleText("2");
            try {
                Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "other_loan_amount"))).sendKeys("0");
            } catch (Exception E) {
            }

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "PropListed"))).click();

            // Select selectPurchaseSechem = new
            // Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
            // "Scheme"))));
            // selectPurchaseSechem.selectByVisibleText("No");

            // Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
            // "EstPrice"))).sendKeys("300000");

            Select selectPropertyConstructed = new Select(Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property",
                "PropConstr_EO"))));
            selectPropertyConstructed.selectByVisibleText("Timber Frame");
            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Is_Property_let_to_relative"))).click();
            /*
             * Select selectDepositFrom = new Select(
             * Framework.driver.findElement
             * (By.xpath(getobjectdata("GAD2Property", "MethodDeposit"))));
             * selectDepositFrom.selectByVisibleText("Savings");
             */

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continue"))).click();

            Framework.driver.findElement(By.xpath(getobjectdata("GAD2Property", "Continuenav"))).click();
            Framework.log_report("PASS", "GAD1 Property Details Complete", "No");
            if (Journey_Till.equalsIgnoreCase("GAD2 Property Details")) {
                flag = true;
                break Execution;
            }

            /*
             * // Speak to Mortgage Advisor
             * Framework.driver.findElement(By.xpath
             * (getobjectdata("Speak_to_Advisor", "checkbox"))).click();
             * Framework
             * .driver.findElement(By.xpath(getobjectdata("Speak_to_Advisor",
             * "submit"))).click();
             */
            // FCD
            Framework.driver.findElement(By.xpath(getobjectdata("FCD", "Confirm_checkbox"))).click();
            Framework.driver.findElement(By.xpath(getobjectdata("FCD", "FCDCRA"))).click();
            Framework.log_report("PASS", "FCD Complete", "No");

            if (Journey_Till.equalsIgnoreCase("FCD")) {
                flag = true;
                break Execution;
            }


            // Valuation Page
            Common_Functions.Complete_Valuation();
            if (Journey_Till.equalsIgnoreCase("Valuation")) {
                flag = true;
                break Execution;
            }

            // Conveyancing Details Page
            Common_Functions.Complete_ConveyancingDetails();

            if (Journey_Till.equalsIgnoreCase("Conveyancing Details")) {
                flag = true;
                break Execution;
            }
            // DD page
            Common_Functions.Complete_DD();

            if (Journey_Till.equalsIgnoreCase("DD")) {
                flag = true;
                break Execution;
            }

            // Pay Fees
            Common_Functions.Pay_Fees_Customer();
            if (Library.url.equalsIgnoreCase("hk375")) {

                Framework.driver.findElement(By.xpath("//a[@title='Your mortgage application']")).click();
                Thread.sleep(2000);
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next"))).click();
            } else {
                Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
            }
            boolean condition = false;

            try {
                condition = Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "PropVal"))).isDisplayed();
                // System.out.println(condition);
            } catch (Exception E) {
            }
            if (condition) {
                String Testharness_result = MQ_Test_Harness.MQTestHarness(app_id);
                if (Testharness_result.equalsIgnoreCase("return code=0")) {
                    Framework.driver.findElement(By.xpath(getobjectdata("DocsCorres", "PropVal"))).click();
                    Framework.driver.findElement(By.xpath(getobjectdata("Valuation", "ValConfirm"))).click();
                } else {
                    System.out.println("***MQTESTHARNESS Return code not equal to 0");
                    // Framework.driver.quit();
                }
                if (Library.url.equalsIgnoreCase("hk375")) {
                    try {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next_Text"))).click();
                    } catch (Exception e) {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next_Text"))).click();
                    }
                } else {
                    try {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    } catch (Exception e) {
                        Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "JMS_link"))).click();
                    }
                }
            }

            String what_next_text = Framework.driver.findElement(By.xpath(getobjectdata("JMS_Home", "What_Next_Text"))).getText();
            Assert
                .assertEquals(what_next_text,
                    "Thank you. You've given us all of the information we need from you. We'll be in touch soon to give you an update.");

            System.out.println("Execution Completed");
            double endTime = System.currentTimeMillis();
            double totalTime = endTime - startTime;
            totalTime = totalTime / 60000;
            totalTime = Double.parseDouble(new DecimalFormat("##.##").format(totalTime));
            System.out.println("Total Execution Time: " + totalTime + " Minutes");
            // Display_Popup("Thank You!!!", "Execution Complete");
            Framework.log_report("PASS", "Customer Journey Completed till DD", "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");
        } catch (Exception E) {
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "FAIL");
            E.printStackTrace();
            // Display_Popup("Error!!!", "Execution Failed");
            Framework.log_report("FAIL", "Customer HealthCheck Failed", "Yes");
        }
        if (flag) {
            System.out.println("Execution done till:" + Journey_Till);
            Framework.log_report("PASS", "Journey Complete till " + Journey_Till, "Yes");
            update_Result(Mortgage_Data_Creation.E2E_Test.rowCount, "PASS");
        }
    }
}
